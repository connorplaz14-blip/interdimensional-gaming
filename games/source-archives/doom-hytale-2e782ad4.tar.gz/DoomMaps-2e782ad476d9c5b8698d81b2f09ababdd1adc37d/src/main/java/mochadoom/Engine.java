/*
 * Copyright (C) 2017 Good Sign
 * Modified for headless operation in DoomMaps
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package mochadoom;

import awt.DoomWindow;
import awt.DoomWindowController;
import awt.EventBase.KeyStateInterest;
import static awt.EventBase.KeyStateSatisfaction.WANTS_MORE_ATE;
import static awt.EventBase.KeyStateSatisfaction.WANTS_MORE_PASS;
import awt.EventHandler;
import doom.CVarManager;
import doom.CommandVariable;
import doom.ConfigManager;
import doom.DoomMain;
import static g.Signals.ScanCode.SC_ENTER;
import static g.Signals.ScanCode.SC_ESCAPE;
import static g.Signals.ScanCode.SC_LALT;
import static g.Signals.ScanCode.SC_PAUSE;
import i.Strings;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Engine {

    private static final Logger LOGGER = Loggers.getLogger(Engine.class.getName());

    private static volatile Engine instance;
    private static boolean headlessMode = false;

    /**
     * Mocha Doom engine entry point
     */
    public static void main(final String[] argv) throws IOException {
        LOGGER.log(Level.INFO, Strings.MOCHA_DOOM_TITLE);
        final Engine local;
        synchronized (Engine.class) {
            local = new Engine(argv);
        }

        // never returns
        try {
            local.DOOM.setupLoop();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "DOOM.setupLoop failure", e);
            if (!headlessMode) {
                System.exit(1);
            }
        }
    }

    /**
     * Start engine in headless mode (no window)
     */
    public static void startHeadless(final String... argv) throws IOException {
        headlessMode = true;
        main(argv);
    }

    public final CVarManager cvm;
    public final ConfigManager cm;
    public final DoomWindowController<?, EventHandler> windowController;
    public final DoomMain<?, ?> DOOM;

    @SuppressWarnings("unchecked")
    private Engine(final String... argv) throws IOException {
        instance = this;

        // reads command line arguments
        this.cvm = new CVarManager(Arrays.asList(argv));

        // reads default.cfg and mochadoom.cfg
        this.cm = new ConfigManager();

        // intiializes stuff
        this.DOOM = new DoomMain<>();

        // Only create window if not in headless mode
        if (!headlessMode) {
            this.windowController = DoomWindow.createCanvasWindowController(
                        DOOM.graphicSystem::getScreenImage,
                        DOOM::PostEvent,
                        DOOM.graphicSystem.getScreenWidth(),
                        DOOM.graphicSystem.getScreenHeight()
                );

            windowController.getObserver().addInterest(
                    new KeyStateInterest<>(obs -> {
                        EventHandler.fullscreenChanges(windowController.getObserver(), windowController.switchFullscreen());
                        return WANTS_MORE_ATE;
                    }, SC_LALT, SC_ENTER)
            ).addInterest(
                    new KeyStateInterest<>(obs -> {
                        if (!windowController.isFullscreen()) {
                            if (DOOM.menuactive || DOOM.paused || DOOM.demoplayback) {
                                EventHandler.menuCaptureChanges(obs, DOOM.mousecaptured = !DOOM.mousecaptured);
                            } else {
                                EventHandler.menuCaptureChanges(obs, DOOM.mousecaptured = true);
                            }
                        }
                        return WANTS_MORE_PASS;
                    }, SC_LALT)
            ).addInterest(
                    new KeyStateInterest<>(obs -> {
                        if (!windowController.isFullscreen() && !DOOM.mousecaptured && DOOM.menuactive) {
                            EventHandler.menuCaptureChanges(obs, DOOM.mousecaptured = true);
                        }
                        return WANTS_MORE_PASS;
                    }, SC_ESCAPE)
            ).addInterest(
                    new KeyStateInterest<>(obs -> {
                        if (!windowController.isFullscreen() && !DOOM.mousecaptured && DOOM.paused) {
                            EventHandler.menuCaptureChanges(obs, DOOM.mousecaptured = true);
                        }
                        return WANTS_MORE_PASS;
                    }, SC_PAUSE)
            );
        } else {
            this.windowController = null;
        }
    }

    /**
     * Temporary solution. Will be later moved in more detailed place
     */
    public static void updateFrame() {
        if (instance != null && instance.windowController != null) {
            instance.windowController.updateFrame();
        }
    }

    public String getWindowTitle(double frames) {
        if (cvm.bool(CommandVariable.SHOWFPS)) {
            return String.format("%s - %s FPS: %.2f", Strings.MOCHA_DOOM_TITLE, DOOM.bppMode, frames);
        } else {
            return String.format("%s - %s", Strings.MOCHA_DOOM_TITLE, DOOM.bppMode);
        }
    }

    public static Engine getEngine() {
        Engine local = Engine.instance;
        if (local == null) {
            synchronized (Engine.class) {
                local = Engine.instance;
                if (local == null) {
                    try {
                        Engine.instance = local = new Engine();
                    } catch (IOException ex) {
                        LOGGER.log(Level.SEVERE, "Engine I/O error", ex);
                        throw new Error("This launch is DOOMed");
                    }
                }
            }
        }

        return local;
    }

    public static CVarManager getCVM() {
        return getEngine().cvm;
    }

    public static ConfigManager getConfig() {
        return getEngine().cm;
    }

    public static boolean isHeadless() {
        return headlessMode;
    }

    public static void shutdown() {
        instance = null;
        headlessMode = false;
    }
}