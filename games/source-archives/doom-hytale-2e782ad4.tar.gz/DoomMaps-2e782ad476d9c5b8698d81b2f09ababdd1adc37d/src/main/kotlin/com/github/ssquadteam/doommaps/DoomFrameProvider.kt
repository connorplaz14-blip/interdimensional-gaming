package com.github.ssquadteam.doommaps

import com.github.ssquadteam.videomaps.FrameProvider
import java.awt.RenderingHints
import java.awt.image.BufferedImage
import java.awt.image.DataBufferInt

class DoomFrameProvider : FrameProvider {

    override fun getFrame(frameIndex: Int, width: Int, height: Int): IntArray? {
        val engine = DoomEngine.get() ?: return null
        val screenImage = engine.getScreenImage() ?: return null

        val scaled = BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB)
        val g2d = scaled.createGraphics()
        g2d.setRenderingHint(
            RenderingHints.KEY_INTERPOLATION,
            RenderingHints.VALUE_INTERPOLATION_BILINEAR
        )
        g2d.drawImage(screenImage, 0, 0, width, height, null)
        g2d.dispose()

        // Extract pixels and convert color format for Hytale map
        // Java ARGB: 0xAARRGGBB -> Hytale RGBA: 0xRRGGBBAA
        val pixels = IntArray(width * height)
        for (i in 0 until width * height) {
            val x = i % width
            val y = i / width
            val argb = scaled.getRGB(x, y)
            val a = (argb shr 24) and 0xFF
            val r = (argb shr 16) and 0xFF
            val g = (argb shr 8) and 0xFF
            val b = argb and 0xFF
            // Pack as RGBA: R<<24 | G<<16 | B<<8 | A
            pixels[i] = (r shl 24) or (g shl 16) or (b shl 8) or a
        }
        return pixels
    }
}
