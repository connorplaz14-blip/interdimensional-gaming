package com.github.ssquadteam.doommaps

import com.github.ssquadteam.doommaps.command.DoomCommand
import com.github.ssquadteam.talelib.TalePlugin
import com.github.ssquadteam.talelib.player.name
import com.github.ssquadteam.talelib.teleport.teleport
import com.github.ssquadteam.videomaps.MapDisplayManager
import com.hypixel.hytale.server.core.entity.entities.Player
import com.hypixel.hytale.server.core.plugin.JavaPluginInit
import com.hypixel.hytale.server.core.universe.PlayerRef
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class DoomMapsPlugin(init: JavaPluginInit) : TalePlugin(init) {

    companion object {
        lateinit var instance: DoomMapsPlugin
            private set
    }

    private val playingPlayers = ConcurrentHashMap.newKeySet<String>()

    val dataFolder: File by lazy {
        pluginDataPath.toFile().also { it.mkdirs() }
    }

    override fun onSetup() {
        instance = this
        info("DoomMaps initializing...")
        info("Place doom1.wad in: ${dataFolder.absolutePath}")

        // Register the input system for movement detection (WASD + Jump)
        entityStoreRegistry.registerSystem(DoomInputSystem())
    }

    override fun onStart() {
        taleCommands.register(DoomCommand())
        info("DoomMaps ready!")
    }

    fun addPlayer(player: Player, displayId: String) {
        val playerRef = player.playerRef ?: return
        val world = player.world ?: return
        playingPlayers.add(playerRef.name)
        MapDisplayManager.addViewer(displayId, player)

        // Set player facing direction for proper DOOM controls
        // Must run on world thread for ECS store access
        world.execute {
            val position = playerRef.transform.position
            playerRef.teleport(
                position.x,
                position.y,
                position.z,
                yaw = 180f,
                pitch = 0f
            )
        }
    }

    fun removePlayer(player: Player, displayId: String) {
        val playerRef = player.playerRef ?: return
        playingPlayers.remove(playerRef.name)
        MapDisplayManager.removeViewer(displayId, player)

        // Release movement keys
        DoomEngine.get()?.let { engine ->
            engine.moveForward(false)
            engine.moveBackward(false)
            engine.turnLeft(false)
            engine.turnRight(false)
        }
    }

    fun isPlayerPlaying(playerRef: PlayerRef): Boolean {
        return playingPlayers.contains(playerRef.username)
    }

    fun getWadPath(): String? {
        val wadFile = File(dataFolder, "doom1.wad")
        return if (wadFile.exists()) wadFile.absolutePath else null
    }

    override fun onShutdown() {
        playingPlayers.clear()
        DoomEngine.stop()
        info("DoomMaps disabled!")
    }
}
