package com.github.ssquadteam.doommaps

import com.github.ssquadteam.talelib.input.*
import com.hypixel.hytale.server.core.modules.entity.component.TransformComponent
import com.hypixel.hytale.math.vector.Vector3d
import com.hypixel.hytale.protocol.InteractionType
import com.hypixel.hytale.server.core.event.events.player.PlayerInteractEvent
import com.hypixel.hytale.server.core.event.events.player.PlayerMouseButtonEvent
import com.hypixel.hytale.server.core.event.events.player.PlayerMouseMotionEvent
import com.hypixel.hytale.server.core.universe.PlayerRef
import g.Signals.ScanCode
import kotlin.math.abs

class DoomInputHandler(private val playerRef: PlayerRef) {

    private var lastX: Double = 0.0
    private var lastZ: Double = 0.0
    private var hasLastPos = false

    private var currentMovement = MovementState()
    private var wasJumping = false

    data class MovementState(
        var forward: Boolean = false,
        var backward: Boolean = false,
        var left: Boolean = false,
        var right: Boolean = false
    )

    fun handleMouseButton(event: PlayerMouseButtonEvent) {
        val engine = DoomEngine.get() ?: return

        when {
            event.isLeftClick -> engine.useAction(event.isPressed)
            event.isRightClick -> engine.rightClick(event.isPressed)
        }
    }

    fun handleMouseMotion(event: PlayerMouseMotionEvent) {
        val engine = DoomEngine.get() ?: return

        val dx = event.deltaX
        val dy = event.deltaY

        if (dx != 0 || dy != 0) {
            // Mouse motion for turning/looking
            engine.sendMouse(0, dx * 5, dy)
        }
    }

    fun handleInteraction(event: PlayerInteractEvent) {
        val engine = DoomEngine.get() ?: return

        when (event.actionType) {
            InteractionType.Ability1 -> engine.sendKey(ScanCode.SC_1, true)
            InteractionType.Ability2 -> engine.sendKey(ScanCode.SC_2, true)
            InteractionType.Ability3 -> engine.sendKey(ScanCode.SC_3, true)
            InteractionType.Use -> engine.sendKey(ScanCode.SC_ENTER, true)
            else -> {}
        }
    }

    fun updateMovement() {
        val engine = DoomEngine.get() ?: return

        // Space (Jump) = Fire weapon
        val isJumping = playerRef.isJumping
        if (isJumping != wasJumping) {
            engine.leftClick(isJumping)  // Fire while jumping
        }
        wasJumping = isJumping

        // Get current position
        val pos = getPlayerPosition() ?: return
        val currentX = pos.x
        val currentZ = pos.z

        if (!hasLastPos) {
            lastX = currentX
            lastZ = currentZ
            hasLastPos = true
            return
        }

        // Calculate movement delta
        val deltaX = currentX - lastX
        val deltaZ = currentZ - lastZ

        val threshold = 0.001
        val absDeltaX = abs(deltaX)
        val absDeltaZ = abs(deltaZ)
        val forward = absDeltaZ > threshold && deltaZ < 0
        val backward = absDeltaZ > threshold && deltaZ > 0
        val left = absDeltaX > threshold && deltaX < 0
        val right = absDeltaX > threshold && deltaX > 0

        if (forward != currentMovement.forward) {
            engine.moveForward(forward)
            currentMovement.forward = forward
        }
        if (backward != currentMovement.backward) {
            engine.moveBackward(backward)
            currentMovement.backward = backward
        }
        if (left != currentMovement.left) {
            engine.turnLeft(left)
            currentMovement.left = left
        }
        if (right != currentMovement.right) {
            engine.turnRight(right)
            currentMovement.right = right
        }

        lastX = currentX
        lastZ = currentZ
    }

    private fun getPlayerPosition(): Vector3d? {
        return try {
            val ref = playerRef.reference ?: return null
            if (!ref.isValid) return null
            val store = ref.store
            val transform = store.getComponent(ref, TransformComponent.getComponentType()) as? TransformComponent
            transform?.position as? Vector3d
        } catch (e: Exception) {
            null
        }
    }

    fun releaseAll() {
        val engine = DoomEngine.get() ?: return
        engine.moveForward(false)
        engine.moveBackward(false)
        engine.turnLeft(false)
        engine.turnRight(false)
        engine.leftClick(false)
        engine.rightClick(false)
        currentMovement = MovementState()
        wasJumping = false
        hasLastPos = false
    }
}
