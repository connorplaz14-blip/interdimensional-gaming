package com.github.ssquadteam.doommaps

import com.hypixel.hytale.component.*
import com.hypixel.hytale.component.dependency.*
import com.hypixel.hytale.component.query.*
import com.hypixel.hytale.component.system.tick.*
import com.hypixel.hytale.protocol.*
import com.hypixel.hytale.protocol.packets.player.*
import com.hypixel.hytale.server.core.entity.entities.Player
import com.hypixel.hytale.server.core.entity.movement.*
import com.hypixel.hytale.server.core.modules.entity.component.*
import com.hypixel.hytale.server.core.modules.entity.player.*
import com.hypixel.hytale.server.core.universe.*
import com.hypixel.hytale.server.core.universe.world.storage.*
import com.hypixel.hytale.server.core.util.*
import kotlin.math.abs

class DoomInputSystem : EntityTickingSystem<EntityStore>() {

    private val inputQuery: Query<EntityStore> = Query.and(
        PlayerInput.getComponentType(),
        TransformComponent.getComponentType(),
        PlayerRef.getComponentType()
    )

    private val deps: Set<Dependency<EntityStore>> = setOf(
        SystemDependency(Order.BEFORE, PlayerSystems.ProcessPlayerInput::class.java)
    )

    // Action state tracking
    private var isFiring = false
    private var fireHoldTicks = 0
    private var isUsing = false
    private var useHoldTicks = 0
    private var isEntering = false
    private var enterHoldTicks = 0
    private var isEscaping = false
    private var escapeHoldTicks = 0

    // Weapon selection state tracking
    private var isSelectingWeapon = false
    private var weaponSelectTicks = 0
    private var selectedWeaponNum = 0

    // Hotbar slot tracking for weapon/action selection
    private var lastHotbarSlot: Byte = -1

    override fun tick(
        dt: Float,
        index: Int,
        archetypeChunk: ArchetypeChunk<EntityStore>,
        store: Store<EntityStore>,
        commandBuffer: CommandBuffer<EntityStore>
    ) {
        val engine = DoomEngine.get() ?: return

        val playerInput = archetypeChunk.getComponent(index, PlayerInput.getComponentType()) ?: return
        val transform = archetypeChunk.getComponent(index, TransformComponent.getComponentType()) ?: return
        val playerRef = archetypeChunk.getComponent(index, PlayerRef.getComponentType()) ?: return

        if (!DoomMapsPlugin.instance.isPlayerPlaying(playerRef)) return

        val ref = archetypeChunk.getReferenceTo(index)

        // Hotbar slot detection for weapon/action selection
        val playerComponent = store.getComponent(ref, Player.getComponentType())
        if (playerComponent != null) {
            val currentSlot = playerComponent.inventory.activeHotbarSlot
            if (currentSlot != lastHotbarSlot && lastHotbarSlot != (-1).toByte()) {
                handleHotbarSlotChange(engine, currentSlot.toInt())
            }
            lastHotbarSlot = currentSlot
        }

        // Jump = Fire weapon (other actions handled via hotbar slots)
        val movementComponent = store.getComponent(ref, MovementStatesComponent.getComponentType())
        val isJumping = movementComponent?.movementStates?.jumping == true

        if (isJumping && !isFiring) {
            isFiring = true
            fireHoldTicks = 10
        }

        // Handle fire action
        if (isFiring) {
            engine.leftClick(true)
            fireHoldTicks--
            if (fireHoldTicks <= 0) {
                isFiring = false
                engine.leftClick(false)
            }
        }

        // Handle use action
        if (isUsing) {
            engine.useAction(true)
            useHoldTicks--
            if (useHoldTicks <= 0) {
                isUsing = false
                engine.useAction(false)
            }
        }

        // Handle enter action (menu select)
        if (isEntering) {
            engine.enterKey(true)
            enterHoldTicks--
            if (enterHoldTicks <= 0) {
                isEntering = false
                engine.enterKey(false)
            }
        }

        // Handle escape action (menu back)
        if (isEscaping) {
            engine.escapeKey(true)
            escapeHoldTicks--
            if (escapeHoldTicks <= 0) {
                isEscaping = false
                engine.escapeKey(false)
            }
        }

        // Handle weapon selection (press and release number key)
        if (isSelectingWeapon) {
            engine.selectWeapon(selectedWeaponNum, true)
            weaponSelectTicks--
            if (weaponSelectTicks <= 0) {
                isSelectingWeapon = false
                engine.selectWeapon(selectedWeaponNum, false)
            }
        }

        val movementQueue = playerInput.movementUpdateQueue

        for (i in 0 until movementQueue.size) {
            val update = movementQueue[i]
            if (update is PlayerInput.AbsoluteMovement) {
                val currentPos = transform.position

                // Detect jump from Y-movement delta -> Fire weapon
                val deltaY = update.y - currentPos.y
                if (deltaY > 0.1 && !isFiring) {
                    isFiring = true
                    fireHoldTicks = 10
                }

                // Block XZ movement (player stays in place while playing DOOM)
                val xzDistSq = (update.x - currentPos.x) * (update.x - currentPos.x) +
                               (update.z - currentPos.z) * (update.z - currentPos.z)

                if (xzDistSq > 0.01) {
                    val clientTeleport = ClientTeleport(
                        i.toByte(),
                        ModelTransform(
                            PositionUtil.toPositionPacket(currentPos),
                            PositionUtil.toDirectionPacket(transform.rotation),
                            null
                        ),
                        true
                    )
                    playerRef.packetHandler.write(clientTeleport)
                }

                // Map player movement to DOOM controls
                var w = false
                var a = false
                var s = false
                var d = false

                val deltaX = update.x - currentPos.x
                val deltaZ = update.z - currentPos.z

                if (abs(deltaZ) > abs(deltaX)) {
                    if (deltaZ > 0) s = true else w = true
                } else if (abs(deltaX) > 0.001) {
                    if (deltaX > 0) d = true else a = true
                }

                engine.moveForward(w)
                engine.turnLeft(a)
                engine.moveBackward(s)
                engine.turnRight(d)
            } else {
                engine.moveForward(false)
                engine.turnLeft(false)
                engine.moveBackward(false)
                engine.turnRight(false)
            }
        }

        movementQueue.clear()
    }

    override fun getQuery(): Query<EntityStore> = inputQuery

    override fun getDependencies(): Set<Dependency<EntityStore>> = deps

    /**
     * Handle hotbar slot changes for DOOM controls:
     * - Slots 0-3 (keys 1-4): Select weapons 1-4
     * - Slot 4 (key 5): Fire weapon
     * - Slot 5 (key 6): Use action (doors/switches)
     * - Slot 6 (key 7): Enter (menu select)
     * - Slot 7 (key 8): Escape (menu back)
     */
    private fun handleHotbarSlotChange(engine: DoomEngine, slot: Int) {
        when (slot) {
            // Weapon selection (slots 0-3 = keys 1-4)
            0, 1, 2, 3 -> {
                // Release previous weapon key if mid-selection
                if (isSelectingWeapon && selectedWeaponNum > 0) {
                    engine.selectWeapon(selectedWeaponNum, false)
                }
                isSelectingWeapon = true
                weaponSelectTicks = 5
                selectedWeaponNum = slot + 1  // slot 0 = weapon 1, etc.
            }

            // Action triggers (slots 4-7 = keys 5-8)
            4 -> {
                // Fire weapon
                isFiring = true
                fireHoldTicks = 10
            }
            5 -> {
                // Use action (doors/switches)
                isUsing = true
                useHoldTicks = 8
            }
            6 -> {
                // Enter (menu select)
                isEntering = true
                enterHoldTicks = 5
            }
            7 -> {
                // Escape (menu back)
                isEscaping = true
                escapeHoldTicks = 5
            }
        }
    }
}
