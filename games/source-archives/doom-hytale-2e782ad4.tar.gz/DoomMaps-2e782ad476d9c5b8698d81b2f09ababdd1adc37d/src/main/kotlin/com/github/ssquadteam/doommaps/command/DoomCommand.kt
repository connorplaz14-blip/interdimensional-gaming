package com.github.ssquadteam.doommaps.command

import com.github.ssquadteam.doommaps.DoomEngine
import com.github.ssquadteam.doommaps.DoomFrameProvider
import com.github.ssquadteam.doommaps.DoomMapsPlugin
import com.github.ssquadteam.talelib.command.TaleCommand
import com.github.ssquadteam.talelib.command.TaleContext
import com.github.ssquadteam.talelib.message.*
import com.github.ssquadteam.videomaps.MapDisplayManager

class DoomCommand : TaleCommand("doom", "Play DOOM on the world map") {

    companion object {
        const val DISPLAY_ID = "doom_display"
    }

    init {
        subCommand(StartCommand())
        subCommand(StopCommand())
        subCommand(JoinCommand())
        subCommand(LeaveCommand())
        subCommand(StatusCommand())
    }

    override fun onExecute(ctx: TaleContext) {
        ctx.reply("DOOM Commands:".info())
        ctx.reply("  /doom start - Start DOOM engine".muted())
        ctx.reply("  /doom stop - Stop DOOM engine".muted())
        ctx.reply("  /doom join - Join as player".muted())
        ctx.reply("  /doom leave - Leave game".muted())
        ctx.reply("  /doom status - Show DOOM status".muted())
    }

    class StartCommand : TaleCommand("start", "Start DOOM") {
        override fun onExecute(ctx: TaleContext) {
            if (DoomEngine.get() != null) {
                ctx.reply("DOOM is already running!".error())
                return
            }

            val wadPath = DoomMapsPlugin.instance.getWadPath()
            if (wadPath == null) {
                ctx.reply("doom1.wad not found!".error())
                ctx.reply("Place doom1.wad in: ${DoomMapsPlugin.instance.dataFolder.absolutePath}".muted())
                return
            }

            if (!MapDisplayManager.exists(DISPLAY_ID)) {
                MapDisplayManager.create {
                    id = DISPLAY_ID
                    startChunkX = 0
                    startChunkZ = 0
                    widthChunks = 10
                    heightChunks = 6
                }
            }

            ctx.reply("Starting DOOM...".info())

            try {
                DoomEngine.start(wadPath)

                Thread.sleep(500)

                MapDisplayManager.startAnimation(
                    displayId = DISPLAY_ID,
                    frameProvider = DoomFrameProvider(),
                    frameCount = 0,
                    fps = 35,
                    loop = true
                )

                ctx.reply("DOOM started! Use /doom join to play.".success())
                ctx.reply("Open your map (M key) to see the game.".muted())
            } catch (e: Exception) {
                ctx.reply("Failed to start DOOM: ${e.message}".error())
                e.printStackTrace()
            }
        }
    }

    class StopCommand : TaleCommand("stop", "Stop DOOM") {
        override fun onExecute(ctx: TaleContext) {
            if (DoomEngine.get() == null) {
                ctx.reply("DOOM is not running.".error())
                return
            }

            MapDisplayManager.stopAnimation(DISPLAY_ID)
            DoomEngine.stop()
            ctx.reply("DOOM stopped.".success())
        }
    }

    class JoinCommand : TaleCommand("join", "Join DOOM game") {
        override fun onExecute(ctx: TaleContext) {
            val player = ctx.requirePlayer() ?: return

            if (DoomEngine.get() == null) {
                ctx.reply("DOOM is not running! Use /doom start first.".error())
                return
            }

            DoomMapsPlugin.instance.addPlayer(player, DISPLAY_ID)
            ctx.reply("Joined DOOM! Open your map (M) to play.".success())
            ctx.reply("Controls:".info())
            ctx.reply("  WASD - Move/Turn".muted())
            ctx.reply("  Jump - Fire weapon".muted())
            ctx.reply("Hotbar Controls:".info())
            ctx.reply("  1-4 - Select weapon".muted())
            ctx.reply("  5 - Fire | 6 - Use (doors)".muted())
            ctx.reply("  7 - Enter | 8 - Escape".muted())
        }
    }

    class LeaveCommand : TaleCommand("leave", "Leave DOOM game") {
        override fun onExecute(ctx: TaleContext) {
            val player = ctx.requirePlayer() ?: return
            DoomMapsPlugin.instance.removePlayer(player, DISPLAY_ID)
            ctx.reply("Left DOOM game.".success())
        }
    }

    class StatusCommand : TaleCommand("status", "Show DOOM status") {
        override fun onExecute(ctx: TaleContext) {
            val engine = DoomEngine.get()
            if (engine == null) {
                ctx.reply("DOOM is not running.".muted())
                return
            }

            ctx.reply("DOOM Status:".info())
            ctx.reply("  Running: ${engine.isRunning()}".muted())
            ctx.reply("  Screen: ${engine.screenWidth}x${engine.screenHeight}".muted())

            val display = MapDisplayManager.get(DISPLAY_ID)
            if (display != null) {
                ctx.reply("  Viewers: ${display.getViewers().size}".muted())
                ctx.reply("  Animating: ${MapDisplayManager.isAnimating(DISPLAY_ID)}".muted())
            }
        }
    }
}
