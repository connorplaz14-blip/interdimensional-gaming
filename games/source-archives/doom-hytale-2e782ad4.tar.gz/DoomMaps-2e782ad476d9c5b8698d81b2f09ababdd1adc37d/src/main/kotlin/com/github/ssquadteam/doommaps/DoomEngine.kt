package com.github.ssquadteam.doommaps

import doom.event_t
import doom.evtype_t
import g.Signals.ScanCode
import mochadoom.Engine
import java.awt.Image
import java.util.concurrent.atomic.AtomicBoolean

class DoomEngine private constructor() {

    companion object {
        private var instance: DoomEngine? = null

        fun start(wadPath: String? = null): DoomEngine {
            if (instance != null) throw IllegalStateException("DOOM already running")
            instance = DoomEngine()
            instance!!.startEngine(wadPath)
            return instance!!
        }

        fun get(): DoomEngine? = instance

        fun stop() {
            Engine.shutdown()
            instance = null
        }
    }

    private val running = AtomicBoolean(false)
    private var gameThread: Thread? = null

    val screenWidth: Int
        get() = Engine.getEngine().DOOM.graphicSystem.getScreenWidth()

    val screenHeight: Int
        get() = Engine.getEngine().DOOM.graphicSystem.getScreenHeight()

    private fun startEngine(wadPath: String?) {
        running.set(true)

        gameThread = Thread({
            try {
                val args = mutableListOf(
                    "-nosound",
                    "-nomusic",
                    "-warp", "1", "1"  // Skip to E1M1 directly
                )
                if (wadPath != null) {
                    args.add("-iwad")
                    args.add(wadPath)
                }
                Engine.startHeadless(*args.toTypedArray())
            } catch (e: Exception) {
                DoomMapsPlugin.instance.warn("DOOM loop error: ${e.message}")
                e.printStackTrace()
            } finally {
                running.set(false)
            }
        }, "DoomMaps-Engine")
        gameThread!!.isDaemon = true
        gameThread!!.start()

        // Wait briefly for initialization
        Thread.sleep(100)
    }

    fun getScreenImage(): Image? {
        return try {
            Engine.getEngine().DOOM.graphicSystem.getScreenImage()
        } catch (e: Exception) {
            null
        }
    }

    fun getDoom() = Engine.getEngine().DOOM

    fun sendKey(scanCode: ScanCode, pressed: Boolean) {
        val eventType = if (pressed) evtype_t.ev_keydown else evtype_t.ev_keyup
        getDoom().PostEvent(event_t.keyevent_t(eventType, scanCode))
    }

    fun sendMouse(buttons: Int, dx: Int = 0, dy: Int = 0) {
        getDoom().PostEvent(event_t.mouseevent_t(evtype_t.ev_mouse, buttons, dx, dy))
    }

    fun leftClick(down: Boolean) = sendMouse(if (down) event_t.MOUSE_LEFT else 0)
    fun rightClick(down: Boolean) = sendMouse(if (down) event_t.MOUSE_RIGHT else 0)

    fun moveForward(active: Boolean) = sendKey(ScanCode.SC_UP, active)
    fun moveBackward(active: Boolean) = sendKey(ScanCode.SC_DOWN, active)
    fun turnLeft(active: Boolean) = sendKey(ScanCode.SC_LEFT, active)
    fun turnRight(active: Boolean) = sendKey(ScanCode.SC_RIGHT, active)

    fun useAction(active: Boolean) = sendKey(ScanCode.SC_SPACE, active)

    // Menu navigation
    fun enterKey(active: Boolean) = sendKey(ScanCode.SC_ENTER, active)
    fun escapeKey(active: Boolean) = sendKey(ScanCode.SC_ESCAPE, active)

    // Weapon selection (1-7)
    fun selectWeapon(num: Int, active: Boolean) {
        val scanCode = when (num) {
            1 -> ScanCode.SC_1
            2 -> ScanCode.SC_2
            3 -> ScanCode.SC_3
            4 -> ScanCode.SC_4
            5 -> ScanCode.SC_5
            6 -> ScanCode.SC_6
            7 -> ScanCode.SC_7
            else -> return
        }
        sendKey(scanCode, active)
    }

    fun isRunning(): Boolean = running.get()
}
