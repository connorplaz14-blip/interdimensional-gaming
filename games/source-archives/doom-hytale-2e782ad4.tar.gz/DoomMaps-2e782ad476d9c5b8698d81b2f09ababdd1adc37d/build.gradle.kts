plugins {
    kotlin("jvm") version "2.0.21"
    java
}

group = "com.github.ssquadteam"
version = "1.0.0"

repositories {
    maven { url = uri("https://jitpack.io") }
    mavenCentral()
}

dependencies {
    compileOnly(files("libs/HytaleServer.jar"))
    compileOnly("com.github.ssquadteam:TaleLib:main-SNAPSHOT")
    compileOnly(files("libs/VideoMaps.jar"))
}

kotlin {
    jvmToolchain(21)
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(21))
    }
}

tasks.jar {
    archiveBaseName.set("DoomMaps")

    from(sourceSets.main.get().output)

    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
}
