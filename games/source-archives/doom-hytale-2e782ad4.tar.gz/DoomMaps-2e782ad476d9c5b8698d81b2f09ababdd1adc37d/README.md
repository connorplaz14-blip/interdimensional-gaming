# DoomMaps

Play DOOM on the Hytale world map. This plugin renders DOOM frames to the in-game map display using the VideoMaps infrastructure.

## Features

- DOOM rendered to the world map at 35 FPS
- Delta compression for reduced bandwidth
- Movement controls via player position

### Controls

#### Movement & Actions

| Input | DOOM Action |
|-------|-------------|
| W / Forward | Move forward |
| S / Backward | Move backward |
| A / Strafe left | Turn left |
| D / Strafe right | Turn right |
| Jump (Space) | Fire weapon |

#### Hotbar Slot Controls

Switch hotbar slots (1-8 keys) for weapon selection and actions:

| Key | DOOM Action |
|-----|-------------|
| 1 | Select Weapon 1 (Fist/Chainsaw) |
| 2 | Select Weapon 2 (Pistol) |
| 3 | Select Weapon 3 (Shotgun) |
| 4 | Select Weapon 4 (Chaingun) |
| 5 | Fire Weapon |
| 6 | Use (doors/switches) |
| 7 | Enter (menu select) |
| 8 | Escape (menu back) |

**How it works**: Switching hotbar slots triggers the corresponding DOOM action. This works while the map is open.

## TODO

- [ ] Sound effects (if possible via Hytale sound API)

## Commands

```
/doom start  - Start the DOOM engine
/doom stop   - Stop the DOOM engine
/doom join   - Join as a player
/doom leave  - Leave the game
```

## Setup

1. Build the plugin: `./gradlew build`
2. Place `doom1.wad` (DOOM shareware WAD) in the plugin data folder
3. Load the plugin on your Hytale server

## Dependencies

- [TaleLib](https://github.com/ssquadteam/TaleLib) - Plugin framework
- [VideoMaps](https://github.com/ssquadteam/VideoMaps) - Map rendering infrastructure

## Credits & Licenses

### MochaDoom / vanilla-mocha-doom

This project includes source code from [MochaDoom](https://github.com/axdoomer/mochadoom) / [vanilla-mocha-doom](https://github.com/joncampbell123/vanilla-mocha-doom), a pure Java port of the DOOM engine.

**License: GNU General Public License v3.0 (GPLv3)**

MochaDoom is free software licensed under the GPLv3. If you distribute this plugin with the MochaDoom source included, you must:
- Include the GPLv3 license text
- Make the source code available
- License derivative works under GPLv3

### Original DOOM

DOOM is a trademark of id Software LLC. The shareware WAD file (`doom1.wad`) is freely distributable but remains copyrighted by id Software.
