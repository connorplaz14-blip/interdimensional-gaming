package dev.libertycraft.net;

import dev.libertycraft.LibertyCraft;
import dev.libertycraft.combat.HostCombat;
import dev.libertycraft.world.HostDig;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;

/**
 * Multiplayer: every player has their own GTA IV, talking to their own Minecraft client. The host's
 * GTA IV reaches the host's integrated server through shared memory; a guest's GTA IV reaches the
 * host's server through these packets instead.
 */
public final class LcNet {
	private LcNet() {
	}

	/** Guest -> server: the guest's GTA IV hit them (as proto::InputEvent kInHurt). */
	public record Hurt(int kind, float hostDamage, int attackerFormId, int flags) implements CustomPacketPayload {
		public static final Type<Hurt> TYPE = new Type<>(Identifier.fromNamespaceAndPath(LibertyCraft.MOD_ID, "hurt"));
		public static final StreamCodec<RegistryFriendlyByteBuf, Hurt> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, Hurt::kind,
			ByteBufCodecs.FLOAT, Hurt::hostDamage,
			ByteBufCodecs.INT, Hurt::attackerFormId,
			ByteBufCodecs.VAR_INT, Hurt::flags,
			Hurt::new
		);

		@Override
		public Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Guest -> server: the guest's GTA IV brought them back after dying (as proto::InputEvent kInRestore). */
	public record Restore() implements CustomPacketPayload {
		public static final Type<Restore> TYPE = new Type<>(Identifier.fromNamespaceAndPath(LibertyCraft.MOD_ID, "restore"));
		public static final StreamCodec<RegistryFriendlyByteBuf, Restore> CODEC = StreamCodec.unit(new Restore());

		@Override
		public Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	// When each guest last asked for a Restore (server ticks): one a minute at most, so it can't be a heal button.
	private static final java.util.Map<java.util.UUID, Integer> LAST_RESTORE = new java.util.HashMap<>();

	/** Server -> guest: the guest died in Minecraft, so their GTA IV player dies too. */
	public record Died(int attackerFormId) implements CustomPacketPayload {
		public static final Type<Died> TYPE = new Type<>(Identifier.fromNamespaceAndPath(LibertyCraft.MOD_ID, "died"));
		public static final StreamCodec<RegistryFriendlyByteBuf, Died> CODEC = StreamCodec.composite(ByteBufCodecs.INT, Died::attackerFormId, Died::new);

		@Override
		public Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Client -> server: the player hit GTA IV's geometry in this cell (HostDig.open). */
	public record DigOpen(int world, BlockPos pos, int material) implements CustomPacketPayload {
		public static final Type<DigOpen> TYPE = new Type<>(Identifier.fromNamespaceAndPath(LibertyCraft.MOD_ID, "dig_open"));
		public static final StreamCodec<RegistryFriendlyByteBuf, DigOpen> CODEC = StreamCodec.composite(
			ByteBufCodecs.INT, DigOpen::world,
			BlockPos.STREAM_CODEC, DigOpen::pos,
			ByteBufCodecs.VAR_INT, DigOpen::material,
			DigOpen::new
		);

		@Override
		public Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Client -> server: cells around a broken dug block that are inside GTA IV's geometry (HostDig.reveal). */
	public record DigReveal(int world, List<BlockPos> cells, List<Integer> materials) implements CustomPacketPayload {
		public static final Type<DigReveal> TYPE = new Type<>(Identifier.fromNamespaceAndPath(LibertyCraft.MOD_ID, "dig_reveal"));
		public static final StreamCodec<RegistryFriendlyByteBuf, DigReveal> CODEC = StreamCodec.composite(
			ByteBufCodecs.INT, DigReveal::world,
			BlockPos.STREAM_CODEC.apply(ByteBufCodecs.list(64)), DigReveal::cells,
			ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(64)), DigReveal::materials,
			DigReveal::new
		);

		@Override
		public Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/**
	 * Client -> server, every client tick while GTA IV drives the player and once when it lets go:
	 * where GTA IV has them (HostDrive.follow). flags: HostDrive.FLAG_DRIVES, FLAG_IN_VEHICLE.
	 */
	public record Drive(double x, double y, double z, float yaw, int flags) implements CustomPacketPayload {
		public static final Type<Drive> TYPE = new Type<>(Identifier.fromNamespaceAndPath(LibertyCraft.MOD_ID, "drive"));
		public static final StreamCodec<RegistryFriendlyByteBuf, Drive> CODEC = StreamCodec.composite(
			ByteBufCodecs.DOUBLE, Drive::x,
			ByteBufCodecs.DOUBLE, Drive::y,
			ByteBufCodecs.DOUBLE, Drive::z,
			ByteBufCodecs.FLOAT, Drive::yaw,
			ByteBufCodecs.VAR_INT, Drive::flags,
			Drive::new
		);

		@Override
		public Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	public static void init() {
		PayloadTypeRegistry.serverboundPlay().register(Drive.TYPE, Drive.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(Drive.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			if (!Double.isFinite(payload.x()) || !Double.isFinite(payload.y()) || !Double.isFinite(payload.z()) || !Float.isFinite(payload.yaw())) {
				return;
			}
			context.server().execute(() -> dev.libertycraft.world.HostDrive.follow(player, payload.x(), payload.y(), payload.z(), payload.yaw(), payload.flags()));
		});
		PayloadTypeRegistry.serverboundPlay().register(Hurt.TYPE, Hurt.CODEC);
		PayloadTypeRegistry.serverboundPlay().register(Restore.TYPE, Restore.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(Restore.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			context.server().execute(() -> {
				int now = context.server().getTickCount();
				Integer last = LAST_RESTORE.get(player.getUUID());
				if (last != null && now - last < 20 * 60) {
					LibertyCraft.LOG.info("[LibertyCraft] guest {} asked for a restore again within a minute; ignored", player.getPlainTextName());
					return;
				}
				LAST_RESTORE.put(player.getUUID(), now);
				HostCombat.restorePlayer(player);
			});
		});
		PayloadTypeRegistry.serverboundPlay().register(DigOpen.TYPE, DigOpen.CODEC);
		PayloadTypeRegistry.serverboundPlay().register(DigReveal.TYPE, DigReveal.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(DigOpen.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			context.server().execute(() -> HostDig.open(player, payload.world(), payload.pos(), payload.material()));
		});
		ServerPlayNetworking.registerGlobalReceiver(DigReveal.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			int[] materials = payload.materials().stream().mapToInt(Integer::intValue).toArray();
			context.server().execute(() -> HostDig.reveal(player, payload.world(), payload.cells(), materials));
		});
		PayloadTypeRegistry.clientboundPlay().register(Died.TYPE, Died.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(Hurt.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			// A hit's worth of damage, whatever the guest's client claims (friends only, but still).
			float damage = Math.max(0.0F, Math.min(payload.hostDamage(), 10000.0F));
			context.server().execute(() -> HostCombat.hurtPlayer(player, payload.kind(), damage, payload.attackerFormId(), payload.flags()));
		});
	}

	/** True if this player plays on this machine (their GTA IV is on the shared-memory link). */
	public static boolean isHost(ServerPlayer player) {
		var server = player.level().getServer();
		return server != null && server.isSingleplayerOwner(player.nameAndId());
	}
}
