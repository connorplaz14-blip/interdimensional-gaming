# LibertyCraft.asi (GTA IV plugin)

The GTA IV side of LibertyCraft: a 32-bit Windows DLL with the `.asi` extension, loaded by
Ultimate ASI Loader from `<gamedir>/plugins/`. It talks to the Minecraft Fabric mod through the
shared-memory protocol in `../protocol/libertycraft_protocol.h` (SkyCraft v11 layout) and lets
Minecraft drive Niko and the camera.

Supported game: GTA IV **1.0.8.0** (1.0.7.0 should work too; anything else is detected and the
plugin stays inactive). Built on [IV-SDK](extern/iv-sdk) (GPL-3.0, git submodule).

## Build (Linux, cross-compiled)

Needs `clang-cl`, `lld-link`, `llvm-rc` (LLVM), `cmake` >= 3.21, `ninja`, and an
[xwin](https://github.com/Jake-Shadle/xwin) sysroot (Microsoft CRT + Windows SDK) at
`<repo>/.tools/xwin` (or set `XWIN_DIR`):

    xwin --accept-license --cache-dir ~/.xwin-cache --arch x86 --arch x86_64 splat --output .tools/xwin

Then (presets are looked up in the current directory, so run them from `asi/`):

    cd asi && cmake --preset release && cmake --build --preset release
    # -> asi/build/release/LibertyCraft.asi (+ LibertyCraft.pdb)
    # from the repo root: cmake --preset release -S asi && cmake --build asi/build/release

`--preset debug` builds `asi/build/debug/`. Copy the `.asi` to
`<gamedir>/plugins/LibertyCraft.asi` (`tools/build.sh` / `tools/launch.sh` do this).

Toolchain (`cmake/clang-cl-xwin.cmake`): `clang-cl --target=i686-pc-windows-msvc /vctoolsdir
<xwin>/crt /winsdkdir <xwin>/sdk`, `/std:c++17 /MT /EHsc /bigobj /W3 /Zi`, `lld-link /machine:x86
/dll /safeseh:no /debug:full`. `/MT` links the CRT statically: the DLL imports only KERNEL32,
USER32 and VERSION. `/safeseh:no` because IV-SDK's hooks are naked functions with inline asm.

IV-SDK quirks handled by the build:

- Its headers define non-inline globals, so it is included by exactly one translation unit,
  `src/dllmain.cpp`, which also `#include`s the SDK-dependent sources (`Game`, `Input`,
  `Collision`, `Render`, `Overlay`) unity-style. `Log`, `Config`, `Link`, `CrashLog` are normal TUs.
- `IVSDK.cpp` includes `<d3dx9.h>` but uses no D3DX: `src/compat/d3dx9.h` stands in for it.
- One construct clang rejects (`*reinterpret_cast<T*>(nullptr)`) is rewritten in a copy of the
  headers made at configure time (`build/*/ivsdk-patched/`); the submodule stays pristine.

## Tests (Linux)

The ring/seqlock core (`src/LinkCore.h`), the coordinate helpers (`src/Coords.h`) and the
vehicle / Niko-mode state machine (`src/DriveLogic.h`) are portable:

    cmake -S asi/tests -B asi/build/tests && cmake --build asi/build/tests && ctest --test-dir asi/build/tests

`tools/fake_minecraft.py` plays the Minecraft side against the real plugin (or any host):

    python3 tools/fake_minecraft.py --circle 3 --demo-section

It acknowledges teleports, walks a circle, prints every input event and a collision summary, and
with `--demo-section` writes an atlas + a few cubes into the render ring.

## Files

| file | what |
|---|---|
| `dllmain.cpp` | the IV-SDK translation unit; registers the hooks, logs the game version |
| `Link.*`, `LinkCore.h` | the shared mapping: transport, seqlocks, rings, overlay swap, heartbeat thread |
| `Game.*` | per frame: SkyState, McState, teleport handshake, mouse look, puppet mode, camera. Walking into or out of an interior (`SkyState.worldId`: 0 outdoors, else GTA's interior; same coordinates) keeps puppet mode: no teleport handshake and no new collision epoch, the 7 x 7 columns around the player are probed again and sent where they changed (`Collision::Refresh`), so Minecraft never loses the floor. Only the game moving the player (more than 5 m in a frame: a warp, a script, a respawn) runs the handshake, and meanwhile Niko stays hidden under the Minecraft body (HostDrive) |
| `Input.*` | window subclass, raw mouse, DIK -> SDL3 scancodes, CPad zeroing |
| `Collision.*`, `collision/*` | v2: GTA's static collision sampled with one-sided line probes (`CWorld::ProcessLineOfSight`) per 8x8-block column: floors, ceilings and walls -> kColTris / kColRegion (region scheduler from SkyCraft); the water grid. `collision/Geometry.h` is SDK-free and tested on Linux (`tests/collision_test.cpp`). Street furniture (lamp posts, bins, benches, hydrants: GTA *objects*) in the 5x5 columns around the player: each object probed once with OBJECTS-only probes that skip everything else, as oriented boxes merged into the column's regions; doors, tiny and attached objects are left out, moved objects are re-probed once still (`collision/Objects.h`, SDK-free, tested; logged as `collision objects 10s`). Columns more than 7 regions from the player are forgotten (every 2 s once over 225 are held) with a kColForget each (`collision: N far columns forgotten`): Minecraft drops a forgotten column's triangles once the player is 8 regions from it and its voxels at 18, so a long drive no longer fills Minecraft's memory |
| `Render.*` | `drawingEvent`: snapshots the frame's camera (render phase grcViewport / final cam), clock and flags into a draw command of our own that GTA's render thread executes; drains the render ring there |
| `render/World.*` | the D3D9 block renderer: atlas + mips, section vertex buffers, entities/scene/avatar, outline and cracks, Minecraft lighting, depth-tested against GTA's (FusionFix log) depth |
| `render/RenderMath.h`, `render/Shaders.h`, `render/Frame.h`, `render/D3D9Util.h` | pure helpers (tested on Linux), the HLSL (compiled at runtime by d3dcompiler_47), the frame snapshot, D3D9 helpers |
| `render/OpaqueDepth.*` | GTA's glass doesn't hide the blocks and the body behind it (see Rendering): GTA's scene depth copied in GTA's frame before its transparent pass (hooks on `SetRenderTarget` and `SetTexture`) and written back where that pass made it nearer before the blocks are drawn; `DebugFrameTrace` logs a frame's device calls |
| `render/Shadows.h`, `render/ShadowPass.*` | sun shadows (see Rendering): GTA's cascade layout and lookup (`Shadows.h`, SDK-free, tested in `tests/render_test.cpp`), our own cascade atlas, the caster passes and the pass that darkens GTA's world in the blocks' shadow |
| `Overlay.*` | Minecraft's GUI/HUD composited over the frame (premultiplied alpha, crosshair invert pass, cursor). Minecraft ships only what changed (the protocol's dirty tiles, `kOverlayFlagTiles`: a 16 x 16 grid; frames that didn't change aren't published at all), and the overlay texture is updated with just the tiles it lacks of the newest frame, one lock over their bounds (`render/OverlayTiles.h`, tested), or whole when it missed a frame's tile list; logged as `overlay: N uploads so far` |
| `HostDrive.*`, `DriveLogic.h`, `drive/VehicleHit.h` | vehicles and Niko mode: who drives the player (Minecraft or GTA IV); after a vehicle or a knockdown GTA keeps Niko until he really stands; any vehicle running into the puppeted player (or one of GTA's explosions) knocks them over, a helicopter's spinning rotor too (`RagdollOnVehicleHit`). `drive/VehicleHit.h` is SDK-free and tested on Linux (`tests/drive_test.cpp`) |
| `Missions.*`, `drive/SceneLogic.h` | GTA IV's mission scripts and Minecraft mode (see Mission scripts): a script that takes the player over on foot (his control off, its camera, its tasks on him, a minigame) gets him while it does (GTA drives, `Why::kScript`, the Minecraft body on Niko); GTA's cutscenes and the scripts' cameras pause Minecraft (`kSkyScene`), phone calls duck its sounds (`kSkyPhoneCall`); mission characters go to Minecraft as `kActorMission` and no mob's hit or blast reaches them. `SceneLogic.h` is SDK-free and tested on Linux (`tests/scene_test.cpp`) |
| `NikoBody.*`, `render/Body.h` | the Minecraft body on Niko's skeleton (`MinecraftBody`): while GTA animates Niko (vehicles, knockdowns, cutscenes, Niko mode) he is hidden and Minecraft's standing body (`kRenRagdoll`) is drawn with each part on his bones, sized to him (see Vehicles and Niko mode). `render/Body.h` is SDK-free and tested on Linux (`tests/body_test.cpp`) |
| `ViewportRoom.*` | the room GTA renders from at interiors: GTA IV draws an interior's rooms (and the outside only through their portals) from the room its game viewport's portal tracker is in, which follows the viewport's camera (Minecraft's, since we overwrite the final camera: measured) through the portals it crosses. Minecraft's third-person camera passes through the wall beside a door, so the tracker stayed in the stairwell with the camera out in the street and the building hung in a void. Each frame while puppeting (and 1.5 s after, while GTA's camera jumps back to Niko), near an interior (the camera in an interior's bounds, `GET_INTERIOR_AT_COORDS`, or the tracker in one, `GET_KEY_FOR_VIEWPORT_IN_ROOM` not -1): the camera outside every interior's bounds for 2 frames with the tracker in one: `CLEAR_ROOM_FOR_VIEWPORT` (outside); a camera away from the player's eye (third person) in an interior's bounds (they reach metres out into the street): the game's own room search where the camera is, each time it has moved 0.25 m (0.5 s at a slower pace): `SET_ROOM_FOR_VIEWPORT_BY_KEY` with key 0 (room boxes, then a probe down for the room the collision below belongs to; nothing: outside; 0x91E8C0 on 1.0.8.0), with this frame's camera position put into the viewport first (+0x80 of the object at 0x11F8290, code bytes checked). Logged as `[room] stats 10s` |
| `Coords.h` | GTA <-> MC coordinates, heading <-> yaw, camera basis |
| `Combat.*`, `combat/CombatMath.h` | actor table (peds, and vehicles as rows of small boxes -> Minecraft stand-ins: each car model's shape is measured once with line probes against the collision of a parked one (body width without the mirrors, ends, the top every 1/40 of the length, the greenhouse's width; logged as `vehicle shape`), and the boxes hug the body within 5 cm whichever way it faces, as tall as the bonnet and boot where they are, so a hit over the bonnet reaches whoever hides behind it, with a narrower row for the cabin), Minecraft hits/explosions/death -> GTA (vehicle hits: body/engine damage and fire; where a hit landed (`kEvHitPoint`) is followed into the car's model box, so a blow or an arrow on a side window's glass breaks that window (no native breaks a windscreen; the window native is checked against the game's code once, and only used on a settled, intact vehicle whose model has that window) and an arrow through any glass hits whoever sits behind it, who dies slumped in the seat), GTA damage to the puppeted player -> `kInHurt` (with the weapon's kind, found with `HAS_CHAR_BEEN_DAMAGED_BY_WEAPON` since the ped's last damage weapon field is unset on 1.0.8.0, and the direction it came from, so Minecraft's shield blocks what comes from in front; while the shield is up (`kMcBlocking`) such a hit leaves Niko quiet: GTA's pain voice (0x83AB60, hooked after a byte check) is skipped for hits from within the shield's front arc, the same test Minecraft makes, and reaction animations are off; hits from behind sound as usual); in Minecraft mode (puppeted, knocked over, and in a vehicle: getting in, seated, bailing out, getting back up) the player's health stays at a buffer of 1000 that GTA can't take, and GTA's radar arcs show Minecraft's health and armour instead (see `GtaHud`); only Niko mode gives GTA its own health back (see Vehicles and Niko mode). The vehicle the player uses goes into the actor table too, as `kActorPlayerVehicle` (Minecraft makes no stand-in of it, only runs its mobs over with it), vehicles with someone in them carry `kActorOccupied` (Minecraft's hostile mobs go for them; the driver and passengers are read off the vehicle, as is the flag of traffic whose driver GTA creates on demand: `GET_DRIVER_OF_CAR` would create him), and every table write is stamped (`ActorTable.stamp`, QPC: Minecraft takes the vehicles' speeds from it) |
| `MobFight.*` | GTA IV's peds and Minecraft's mobs (`PedsFightMobs`). Minecraft reports its hostile mobs near the player every 5 ticks (`kEvMob`: where, how big, which ped they are after). The ped a mob is after, and police within 25 m of it (3 at most), deal with it every 0.25 s: armed peds and police (a cop without a gun is given a pistol) shoot at the mob's chest (`TASK_SHOOT_AT_COORD`, renewed every 1.8 s, sooner when the mob moved 1.2 m from where they aim; `DebugMobShoot=1`: aim and `FIRE_PED_WEAPON`), the rest run from it within 15 m (`TASK_SMART_FLEE_POINT`); a driver whose car a mob hits drives off. A mob's hits reach peds and vehicles through their stand-ins flagged `kHitByMob`: Combat applies them as usual but they are no crime of the player's and the victim deals with the mob instead of the player; a mob's blast (`kExplosionByMob`) is no crime either. GTA's bullets hit the mobs: the bullet trace hook (NpcBlocks) ends a shot at the first mob box on its way (in front of Minecraft's blocks), and when GTA finds nothing in front of it the mob took it: `kInMobHit` with the shooter (the nearest ped to the muzzle, or the player) and the weapon's damage / 5 (`kMobDamageScale`: a pistol's 25 is 5 Minecraft damage, four shots for a zombie). Logged as `cop N shoots at Minecraft mob`, `ped N runs from Minecraft mob`, `a GTA bullet ... hit Minecraft mob` and `[mobs] stats 10s` |
| `SkyControl.*` | one sky: Minecraft's `/time set`, `/time add` and a night slept through come as `kEvSetTime` (GTA's hour: Minecraft's tick / 1000 + 6) and set GTA's clock (`SET_TIME_OF_DAY`); `/weather clear`, `rain`, `thunder` come as `kEvSetWeather` and force EXTRASUNNY, RAIN or LIGHTNING (`FORCE_WEATHER_NOW`) for the command's duration, then `RELEASE_WEATHER` gives GTA its own weather back. GTA's weather goes to Minecraft in SkyState's flags (bits 8 to 11: `kSkyWeatherShift`, the type + 1), whose own weather cycle stops while linked and follows it. Logged as `Minecraft set the time`, `Minecraft set the weather` |
| `PauseMenu.*` | GTA's pause menu: the `DebugPauseMenu` and `DebugDriveWander` test hooks, and what is known about the menu's own textures: it draws its map, tabs and backgrounds from the `frontend` texture dictionary, loaded when it opens (0x47BFA0) and released when it closes (0x47C0C0). A load that fails leaves the dictionary's slot referenced but empty: a white map with only its blips, and closing the menu then writes to 0x0000000C (0x8CC398) and ends the game. Players saw that after a minute or two of driving, while Combat asked `GET_DRIVER_OF_CAR` of every vehicle near the player every frame: on traffic whose driver GTA creates on demand that native creates him (see Combat). While the menu is open Minecraft pauses too (the mod's `GtaMenuPause`: a singleplayer world and its sounds stand still) and Combat lets nothing act on GTA's world: Minecraft's hits, blasts and mob reports are dropped, the player's death and `/time`, `/weather` wait for the menu to close, MobFight, NpcBlocks and Hazards rest |
| `Doors.*` | GTA's doors swing open for the Minecraft player (Niko is frozen with collision off, so he never pushes one): a door (object pool, `collision/Objects.h`'s door shape) opens away from the player when they walk into it, through GTA's door state (`SET_STATE_OF_CLOSEST_DOOR_OF_TYPE`; object heading or a push as fallbacks), and is shut and handed back to GTA once they are clear |
| `NpcBlocks.*`, `combat/BlockPush.h` | Minecraft's blocks are solid for GTA's peds and vehicles: `kRenSolids` bitsets (handed over by `render/World.cpp`'s ring consumer) push peds out of block columns (they follow walls round) and take the speed into blocks off cars and bikes; and they stop GTA's gunfire: GTA's bullet trace (0x92DAA0, hooked after a byte check) first marches each shot through the solid blocks (`blocks::RayFirstSolid`) and ends it at the first block's face, so nothing behind the blocks is hit (the player, peds, vehicles) and the tracer stops there; where nothing in front took the shot, GTA's concrete impact effect is triggered there and Minecraft is told (`kInBulletImpact`) to show the block's hit particles and sound (GTA's own effects are drawn under Minecraft's blocks). `BlockPush.h` is SDK-free and tested on Linux (`tests/combat_test.cpp`) |
| `Hazards.*`, `hazard/HazardGrid.h` | Minecraft's fire, lava, magma and water for GTA's peds and vehicles. The hazard bits of `kRenLights` (every fire, lava and magma block emits light) and `kRenLiquids` (each section's water and lava: surface height and kind) are handed over by `render/World.cpp`'s ring consumer and applied on the game thread. Peds on foot in fire or lava are set alight (`START_CHAR_FIRE`) and hurt as Minecraft hurts its own (magma only hurts), burn on for a few seconds and are put out; vehicles whose model box touches fire lose engine health until GTA's engine fire and explosion, lava sets them alight at once (`HazardsBurnVehicles`); in water or lava a vehicle struggles, more the deeper it sits (`LiquidsSlowVehicles`: only part of the engine's push takes, drag, a top speed it's eased down to, through its physics collider's velocity every frame), and over a metre of water its engine runs on for 3 s (GTA's own drowning measured 2.4 to 3.2 s), then stalls and is held off while it's that deep, and starts again out of it; water never damages a vehicle. Peds wade slower in it (`LiquidsSlowPeds`). `HazardGrid.h` is SDK-free and tested on Linux (`tests/hazard_test.cpp`) |
| `BlockyCity.*` | the blocky city (`kMcBlockyCity`, see The blocky city below): GTA's map geometry (buildings, terrain, props, their LODs and shadows) hidden while Minecraft's player is in it |
| `collision/Rays.h` (materials) | every line probe's hit carries GTA's material of the surface it hit (`HitMaterial`), and the floors, ceilings and walls built from the probes carry it in their `ColTri` flags (`kTriGtaMaterial`, bits 16 to 23) for the blocky city's blocks (`CityMaterials`) |
| `Config.*`, `Log.*`, `CrashLog.*`, `Perf.h` | ini, log file, crash handler, frame-time stats |

Hooks: `processScriptsEvent` -> `Game::Tick` (natives), `processCameraEvent` -> `Game::Camera`
(after the final camera is written), `processPadEvent` -> `Input::Pad`, `drawingEvent` ->
`Render::Draw`, `ingameStartupEvent` -> `Game::OnIngameStartup`. A background thread beats the
host heartbeat every 250 ms (through loading screens, the pause menu and alt-tab) and reopens
the bridge file if Minecraft deleted/replaced it.

## Rendering (Render, render/, Overlay)

GTA IV records each frame's draw commands on the game thread and executes them on its render
thread, so Direct3D must not be touched from `drawingEvent` (CRenderPhasePostRenderViewport's
draw-list build, twice per frame). `Render::Draw` instead allocates a draw command of our own in
that draw list: the game's `CDrawRectDC` constructor writes the header (id/size word), then the
vtable is swapped for ours `{destructor, Execute, GetSize}` (the layout of every GTA IV DC, see
`CBaseDC`) and the payload is a `render::FrameSnapshot` (camera, clock, what to draw). Its
`Execute` runs on the render thread right after GTA's 3D scene and post-processing, before the
HUD, with the back buffer and GTA's depth buffer (INTZ, same size) still bound. There it drains
the render ring, uploads, draws the blocks (`render/World`) depth-tested against GTA's depth, and
composites Minecraft's overlay. Draws once per game frame (the second command of a frame only
drains); all state it touches is saved/restored with a per-draw `D3DSBT_ALL` state block.

- Camera: `TheCamera.m_pFinalCam` (rows right/forward/up/position, vertical FOV, near/far) as a
  camera-relative clip matrix (camera position subtracted in double). The render phase's
  grcViewport (FusionFix's `+0xB0`) holds no valid viewport in 1.0.8.0 and
  `grcViewport::sm_pCurrent` is a shadow-cascade viewport at that point (both logged); a one-time
  probe looks for the viewport in the phase object. `RenderCamera=` pins a source.
- Depth: with FusionFix loaded the depth buffer is logarithmic (FusionFix's z-fighting fix:
  `z/w = log2(w/near) / log2(far/near)`), which the vertex shader reproduces per vertex; otherwise
  standard D3D depth. `RenderDepth=` overrides.
- Glass (`render/OpaqueDepth.*`, `RenderBehindGlass=1`): our draw command comes after GTA's forward
  pass, whose vehicle and shop windows write depth (only where their reflection is bright, so mostly in
  sunlight), so the body in a car and blocks behind a window failed the depth test. A GTA IV frame
  (`DebugFrameTrace`): the G-buffer pass (4 render targets, its own INTZ depth), that depth copied into
  the scene depth buffer (the INTZ bound at our draw command), decals, the deferred lights, the water,
  then GTA reads the scene depth as a texture for the first time (its R32F copy for refraction and depth
  of field), then the forward pass (vehicle glass among it: blended, with depth writes), post-processing,
  our draw command, and GTA clears the scene depth for its HUD. Hooks on `SetRenderTarget` and
  `SetTexture` (device vtable slots 37 and 65) wait for the G-buffer pass (render target 2 or 3 bound)
  and then for that first read, and right there copy the scene depth, raw (FusionFix's logarithmic
  depth as it is), into an R32F texture of ours, with GTA's render targets, depth buffer and a
  `D3DSBT_ALL` state block put back around it. In our draw command, before the blocks, a full-screen
  pass writes the copy back into the scene depth with a GREATER test, so the depth goes back to what
  is behind only where the forward pass left something nearer. The water (drawn before that read)
  still hides blocks under it; the glass then shows under the blocks and the body instead of over
  them. A frame without the copy (no G-buffer pass seen, no read after it) tests against GTA's depth as
  it is. The copy is `D3DPOOL_DEFAULT` (released in an `IDirect3DDevice9::Reset` hook). A `behind
  glass in N of M drawn frames` line every 10 s gives the CPU and GPU times (measured about 0.05 ms CPU
  and 0.05 ms GPU for both passes at 1920x1080).
- Resources: everything static is `D3DPOOL_MANAGED` (atlas with CPU-built mips, section vertex
  buffers, entity textures, the overlay texture) and per-frame geometry goes through
  `DrawPrimitiveUP`, so the game's device `Reset` needs nothing from us (but for the shadow atlas,
  see Shadows). Section meshes are stored
  as quads (4 vertices + a shared index buffer) when Minecraft's triangles come in (0 1 2)(0 2 3).
- Shaders: HLSL string literals (`render/Shaders.h`) compiled at startup with `D3DCompile` from
  `d3dcompiler_47.dll` (Proton's builtin, vkd3d-shader) to vs_3_0 / ps_3_0.
- Lighting (`render/Lighting.h`, `RenderLighting=gta`): the blocks are lit the way GTA IV lights
  its own world, from the values GTA used this frame, so they follow the time of day, the weather
  and interiors. Every GTA shader shares its globals at fixed registers (read from the game's
  `.fxc` parameter tables): the deferred sun pass lights `albedo * (gDirectionalColour.rgb * .w *
  N.L + lerp(Amb0, Amb1, how much the face looks down))` (`c17`, `c18`, `c37`, `c38`; `c38` holds
  Amb1 minus Amb0), the post-processing fog pass blends towards `globalFogColorN/Color` by view
  depth (`c41` to `c43`, plus the far desaturation `gDepthFxParams` `c16`), and the tone mapping
  multiplies by `Exposure * ToneMapParams.y / adapted luminance` (a 1x1 R32F render target), adds
  bloom above `ToneMapParams.x` times `ToneMapParams.z / 4`, then saturation, `ColorShift`,
  `ColorCorrect * 2` and a luminance gamma (`deSatContrastGamma`). Our draw command runs right
  after the tone mapping: the fog constants and the adapted luminance texture (sampler 5) are
  still bound and are used as they are; the sun/ambient and tone mapping registers have been
  reused by later passes by then, so the plugin watches `SetPixelShaderConstantF` (device vtable
  slot 109) and keeps, per frame, the sun/ambient set most draws used and the tone mapping
  constants its pass set (found by `TexelSize` = 1 / the back buffer size; three register layouts,
  by variant). The shader then does the same maths: HDR light with Minecraft's sky light as
  occlusion (less ambient, no sun under a Minecraft roof), GTA's fog and far desaturation by view
  depth, GTA's tone mapping (its bloom with the pixel's own light standing in for the blurred
  surroundings), `RenderExposure`; block light (torches, glowstone) is a warm floor on the screen,
  rain (`CWeather::Rain`) darkens faces that look up a little. Missing pieces fall back
  separately: no sun pass seen for half a second (or the hook couldn't be placed): Minecraft's own
  lighting (below); no tone mapping constants or no adapted luminance texture: an auto exposure
  stand-in (`RenderSaturation`, `RenderExposureKey`, `RenderExposureFloor`). The `GTA lighting`
  log line says which inputs are in use.
- Minecraft's own lighting (`RenderLighting=minecraft`, and the fallback): texture x vertex colour
  (tint, AO) x Minecraft's face shade (from the normal index) x the light-map curve of max(block,
  sky x day factor from GTA's clock), Minecraft gamma 0.5, `RenderExposure`.
- Shadows (`render/Shadows.h`, `render/ShadowPass.*`, `RenderShadows=1`): the blocks take GTA IV's
  sun shadows and cast their own, onto themselves and onto GTA's world. FusionFix 5 renders GTA's
  sun shadow cascades into one R32F atlas (4 cascades side by side, width = 4 x height, ending at
  10, 30, 85 and 256 m) that is still bound on sampler 15 at our draw command. Its deferred sun pass
  (`deferred_lighting.fxc`) looks a point up with the shadow globals `c53` to `c63`
  (`gShadowMatrix`, each cascade's uv scale and offset, `gFacetCentre`: the camera's depth plus the
  cascades' ends) and FusionFix's filter settings (`c217` to `c223`: softness, normal offset bias,
  4 or 16 rotated Poisson taps, CHSS, cascade blend). The `SetPixelShaderConstantF` watch keeps the
  set most writes used among those made for this frame's camera, and the world shader repeats GTA's
  lookup and filter: a block's sun term is multiplied by it (no sun shadows when GTA's sun pass used
  none for half a second, indoors for example). The blocks, the entities, the avatar and the body
  are drawn into an atlas of our own with the same layout, cascade by cascade (scissored to the
  cascade's quarter; sections culled per cascade and beyond `RenderShadowDistance`), storing the
  value GTA compares with, so one lookup gives both GTA's shadow and GTA's plus the blocks', with
  GTA's own filtering. Before the blocks are drawn, a full-screen pass reads GTA's depth buffer (the
  INTZ texture behind it), rebuilds each pixel's position and normal and multiplies the frame by how
  much less sun the blocks leave it, as GTA's tone mapping shows it (`render/Shadows.h` DarkenFactor):
  the light `ambient * ao + sun * N.L * both` against `ambient * ao + sun * N.L * GTA's` (GTA's own
  split: `ao` is its G-buffer 2's z, still bound on s0 after its tone mapping, and N.L gets FusionFix's
  remap `saturate(N.L * 4/3 - 1/3)`, as in its sun pass), the shaded light pulled towards the lit one by
  GTA's fog, both through GTA's saturation step and luminance gamma (`deSatContrastGamma`), per colour
  channel. So what GTA already shades is left alone and a block shadow is as dark as GTA's on the same
  ground, with the tint GTA's own shadows have there (`RenderShadowStrength`): the HDR ratio alone is
  deep blue under the noon sky and pink under the cyan moon, which GTA's desaturation (0.34 to 0.75)
  mostly takes out of its picture. The
  blocks' own sun term uses the same N.L remap. Our atlas is `D3DPOOL_DEFAULT`: a hook on
  `IDirect3DDevice9::Reset` releases it first. The shadow constants sit in the shaders' low registers
  (`c14` to `c27`; placed at `c100` and up, DXVK sometimes left them unset for the block shader), and
  the `SetPixelShaderConstantF` watch ignores what our own draw command writes. The `GTA sun shadows`
  log line says what is in use; every 10 s a `shadows in N frames` line gives both passes' CPU and
  GPU times (about 0.25 ms CPU and 0.7 ms GPU at 500 sections, measured).
- Cutout is alpha-tested; translucent is sorted by section, back to front.
- In a vehicle Minecraft's rider and its mount reach us a frame or two after GTA moved the seat
  (0.8 m at 50 m/s): the avatar is drawn at this frame's seat (the ped's matrix minus
  `VehicleSeatDrop`, read in `drawingEvent`) and the scene triangles within 2.5 blocks of Minecraft's
  feet (the mount) move by the same amount (`SplitMount`).

## Transport

Under Wine/Proton the plugin opens `Z:\dev\shm\libertycraft-bridge` (= `/dev/shm/libertycraft-bridge`)
with `CreateFileW(OPEN_ALWAYS)`, only ever grows it to `kMappingBytes`, and maps it with
`CreateFileMappingW(PAGE_READWRITE)` in three views (control+rings 32 MiB, overlay 95 MiB
optional, render ring 64 MiB). Without `Z:\dev\shm` it uses the named section
`Local\LibertyCraft_v1`. On attach it resets the host-owned regions, clears `mcPid`, then
publishes `magic`/`version`/`skyrimPid` (the host pid).

## Conventions

- Coordinates: `mc = (x, z, -y)`, `gta = (x, -z, y)`, 1 block = 1 m (`Coords.h`).
- Heading: GTA heading `h` (0 = north, counter-clockwise) and Minecraft yaw (0 = south,
  clockwise): `h = 180 - yaw`. One place: `kHeadingSign` / `kHeadingOffset` in `Coords.h`.
- Pitch: GTA camera pitch (up positive) = -Minecraft pitch (down positive).
- FOV: `McState.fovDeg` is vertical; `FovMode=vertical` copies it into `CCam::m_fFOV` (RAGE's
  grcViewport FOV is vertical; GTA IV is Hor+). `FovMode=horizontal43` converts to the
  horizontal FOV of a 4:3 view instead, if it turns out RAGE wants that.
- Camera matrix: the camera's right / forward / up are `CMatrix` rows `right` / `up` / `at`
  (0, 1, 2), pinned by default (`CameraRows=auto`) so the first puppet frames never use rows
  that are still being discovered. The game's own on-foot camera still cross-checks them once
  (logged as `camera rows check: ... agrees with the pinned rows`); `CameraRows=discover`
  adopts what it finds instead, `CameraRows=0,1,2` style pins other rows.
- Feet: `GET_CHAR_COORDINATES` is the ped's root (~1 m above the soles). The plugin measures
  root z - ground z while the player stands still (logged as `root->feet measured`) and uses
  `RootToFeet` (1.0) until then; puppeting sets the root to MC feet + that offset every frame.
- Placing the ped: not with `SET_CHAR_COORDINATES*`. Every one of those natives ends in
  `CTheScripts::ClearSpaceForMissionEntity` (1.0.8.0: `0x8B1390`), which deletes each ambient car
  and ped touching the player at the destination: every car or pedestrian the puppeted player
  walked into vanished. `PuppetMove=direct` makes only the natives' own move (a virtual call,
  vtable `+0x7C`, found in their common body at `0x8B2BF0`; the code bytes are checked at startup,
  otherwise the native is used).

## LibertyCraft.ini

Next to the `.asi` (`<gamedir>/plugins/LibertyCraft.ini`), written with defaults when missing.

| key | default | meaning |
|---|---|---|
| `Puppet` | `1` | Minecraft drives the player and camera (0: only watch and log) |
| `CameraMode` | `final` | `final`: overwrite `CCamera::m_pFinalCam` after the game's camera update; `scripted`: a `CREATE_CAM(14)` camera driven by natives |
| `FovMode` | `vertical` | `vertical` / `horizontal43`, see Conventions |
| `MenuKey` | `O` | opens Minecraft's pause/options menu (Esc is GTA's); a letter, digit or F1-F12 |
| `Diagnostics` | `0` | stats every second instead of every 10 s, camera matrix dumps |
| `LogPerf` | `1` | one frame-time line a minute (10 s with Diagnostics) |
| `FreezePed` | `1` | `FREEZE_CHAR_POSITION` while puppeting (0: zero the velocity every frame) |
| `PuppetPlayerControl` | `1` | the player keeps GTA's player control while puppeted (its pad is zeroed, so GTA doesn't move him): without it GTA's peds and police take him for a cutscene player and stop fighting and chasing him |
| `GtaHud` | `1` | keep GTA IV's HUD and radar next to Minecraft's HUD in Minecraft mode; GTA still hides them itself in cutscenes and menus (0: Minecraft's HUD only). While Combat owns Niko's health the radar's ring mirrors Minecraft (its health, max health and armour reach us in `McState`'s padding, `kMcVitalsValid`): the HUD's three reads of the player's health (the arc, the flash of what was just lost, where the armour arc starts) call a stub that answers 100 + 100 x Minecraft's health fraction, and its two reads of his max health read 200 (0x87068E, 0x8706C0, 0x86B019, 0x86C869, 0x86C8A5 on 1.0.8.0, each checked byte for byte first), so GTA's own HUD code shows Minecraft's health as its own: the loss flash, the red blink at a quarter or less, the armour arc right after the health arc. GTA's real health stays at the 1000 buffer. GTA's armour is set to Minecraft's armour points x 5 (it absorbs GTA's damage first, which is still sent to Minecraft, and is put back each frame). In Niko mode GTA's own values show (in vehicles Minecraft's too) |
| `PuppetCollision` | `0` | not in the default ini: the puppeted ped keeps its collision (not needed for GTA's peds and police to fight him: with player control on, their shots and blows reach him either way) |
| `RootToFeet` | `1.0` | metres from the ped root to its feet until measured |
| `MeasureRootToFeet` | `1` | measure it in game |
| `ProbeFrom` | `top` | unused since collision v2 (was the v1 heightfield probe start) |
| `ProbeHeight` | `3.0` | unused since collision v2 |
| `CameraRows` | `auto` | `auto` (0,1,2, cross-checked against the game's camera), `discover`, or e.g. `0,1,2` / `-0,1,2` (right, forward, up as CMatrix rows; `-` flips) |
| `Combat` | `1` | combat bridge (0: Minecraft's combat events are drained and ignored, the puppeted player stays invincible) |
| `PedDamageScale` | `10` | Minecraft damage x this = GTA health off a ped (ambient peds have 100) |
| `PlayerDamageScale` | `10` | GTA damage to the puppeted player / this = Minecraft damage |
| `ExplosionType` | `0` | `ADD_EXPLOSION` type for Minecraft explosions |
| `ExplosionRadiusScale` | `1.0` | Minecraft blast radius (blocks) x this = GTA radius (m). (`ADD_EXPLOSION`'s size argument is a share of the type's own radius from `explosionFx.dat`, which the game clamps to 0.01 to 1 (seen in its code, native 0xB13340 -> 0x9940D0): TNT and creepers make their type's full blast; firework blasts pass the share) |
| `FireworkExplosionType` | `2` | `ADD_EXPLOSION` type for a firework rocket with stars (`kExplosionFirework`): the crossbow is an RPG. The burst (Minecraft's `FireworkRocketEntity.explode`: end of flight, or where it struck a creature, a stand-in or a surface; crossbow, hand launch, dispenser or elytra boost) becomes GTA's rocket blast there, 4 m across for one star, a metre more per star, the rocket's full 8 m from five, at full RPG damage within it (peds die and fly, cars burn); no stars, no burst (vanilla). Minecraft's own firework damage never reaches the stand-ins, so peds and vehicles are hurt once. A rocket that struck a vehicle's stand-in also does the rest of an RPG's hit to it a quarter second later if it still runs (500 body and engine health a star, `CombatMath.h FireworkHitDamage`; an engine run below 0 blows it up at once). In game one one-star crossbow rocket brought a hovering police Maverick down every time, 43 m and 80 m away: GTA's blast took its body to 0 and killed the pilot (wrecking it outright twice in three), the rocket's own hit blew up the rest, and it fell; two stars wreck anything with 1000 engine health. Helicopters are stand-ins out to a crossbow rocket's reach (`kAircraftRange`: 1.6 blocks a tick for at most 52 ticks at flight duration 3 = 83.2 m, plus 10 m), ground vehicles to 60 m. The player's own rockets are `CAUSE_EXPLOSION` as far as they fly |
| `HitForce` | `1.0` | how hard a Minecraft hit throws a ped or a body (0 to 5): at 1 a plain sword hit or an arrow sends a ped 7 to 9 m and a Knockback II sprint hit much further; 0.25 is about what a gunshot does to a body (a metre or two) |
| `RagdollOnHit` | `1` | a Minecraft hit ragdolls the ped and pushes it along the knockback (away from the attacker), as hard as `HitForce` says (`CombatMath.h HitShoveForce`). A killing blow on a ped on foot ragdolls and pushes it first and deals the killing damage a couple of frames later, so it dies limp and flies like a gunshot victim instead of playing GTA's death clip (a ped that refuses the ragdoll, about one in ten, still plays it); vehicle occupants keep their seated death. Corpses stay in the actor table (`kActorDead`, a low box over the body between the pelvis and the neck, not solid): a hit or an arrow pushes a body still in its death ragdoll along the knockback (a force, harder for more damage and knockback, times `HitForce`: at 1 a 30-damage blow sends one about 25 m); a settled one lies animated in its dead pose and GTA's dead task won't let it ragdoll again (`SWITCH_PED_TO_RAGDOLL` holds for one frame), so it is thrown along a short arc as it lies (`CorpseFlings`). Peds aren't solid for the Minecraft player: running into one sends `kEvBump` (the player's speed, from its motion this tick, so falls and elytra count) and the ped is moved out of the way at a walk, stumbles from a sprint (5.2 m/s: a 1.5 s balance ragdoll, `SWITCH_PED_TO_RAGDOLL` kind 2, and a light push, so it staggers and stays on its feet), is knocked down from 8 m/s and hurt from 10 m/s (8 health a m/s: an elytra pass at 23 m/s kills, dying in the ragdoll), as a crime (`HIT_PED`); a corpse walked into is dragged and rolled along (CombatMath.h `BumpOf`) |
| `VehicleDamageScale` | `15` | Minecraft damage x this = GTA body and engine health off a vehicle (1000 each). An engine run below 0 catches fire and blows up a few seconds later; an arrow or rocket on a burning one blows it up at once. A blow (a sword, an axe, a fist; crits too) only dents: the body takes all of it, the engine half and never below 300 (smoking), so no number of sword hits sets a car on fire (`CombatMath.h EngineAfterVehicleHit`; arrows and rockets still wreck it) |
| `NpcBlocks` | `1` | Minecraft's blocks are solid for GTA's peds (pushed back out, they follow the wall) and cars and bikes (their speed into the blocks is taken off), and they stop GTA's bullets (not its explosions) |
| `GtaCrimes` | `1` | Minecraft's attacks are GTA crimes: the victim fights back (cops, gangs, one civilian in three) or runs, a driver whose car is hit drives off, and the attack goes to GTA IV's own crime report (`CCrime::ReportCrime`, 0xA503E0, checked byte for byte first) with the player as the criminal: arrows are `SHOOT_PED`/`SHOOT_COP`, blades `STAB_`, anything else `HIT_`, a hit car `DAMAGE_TO_PROPERTY` (`HIT_COP` for a police car's driver), an explosion near the player (the player's firework rocket wherever it flies) `CAUSE_EXPLOSION`; GTA's wanted system then does the rest (witnesses, points, escalation up to the game's maximum, decay). Police killed in one wanted episode also set a floor (1: 2 stars, 3: 3, 6: 4, 10: 5, 15: 6, within `GET_MAX_WANTED_LEVEL`). If the report function isn't found, LibertyCraft's own rules give the wanted level |
| `PedsFightMobs` | `1` | GTA's peds fight back against Minecraft's hostile mobs (MobFight): armed peds and police shoot at a mob that goes after a ped, the rest run, drivers drive off; GTA's bullets hurt the mobs (0: peds ignore mobs and bullets pass through them; mobs still hunt peds) |
| `DebugMobShoot` | `0` | not in the default ini: how peds shoot at mobs (0 `TASK_SHOOT_AT_COORD`, 1 `TASK_AIM_GUN_AT_COORD` and `FIRE_PED_WEAPON`) |
| `DebugMobFight` | `0` | test hook: N s into play, a cop 5 m ahead and 2.5 m left of the player and a civilian 5 m ahead and 2.5 m right stand still (`DebugMobFight: cop ... at MC x y z, civilian ... at MC x y z`, for an autorun to summon mobs beside them); their health and weapon are logged every second for 40 s |
| `DebugWanted` | `0` | test hook: N s into play, 2 wanted stars; then every 3 s for a minute the police's interest (wanted level, cops near, in combat, the shots they fired in those 3 s counted every frame, as `IS_CHAR_SHOOTING` only holds for the frame of a shot, and how often their gunfire hurt the player) and the player's health |
| `DebugStumbleKind` | `-1` | test hook: the ragdoll kind a stumble uses (`SWITCH_PED_TO_RAGDOLL`'s fourth argument, seen in the game's code: 0 a limp fall, 1 scripted, 2 a balance; -1 the default, a balance) |
| `NpcPushMethod` | `0` | not in the default ini: how a ped is moved out of blocks (`0` the entity's own set-position, `1` `SET_CHAR_COORDINATES_NO_OFFSET`) |
| `DebugTestCar` | `0` | test hook: N s into play, park an Admiral with a driver and a front passenger 4 m east of the player (left side toward the player, frozen), log its body health and its people's health as they change, and 90 s later move it 6 m in front of the camera for a screenshot. `-N`: park it 6 m in front of the camera with all four seats taken, and from 8 s on (well past the new-vehicle guard) shoot a lethal arrow through each side window in turn (the same code path as Minecraft's hits; 12 Minecraft damage, so the car stays whole for all four) |
| `DebugTestCarModel` | `admiral` | test hook: DebugTestCar's model (`sabre` has two doors, `pcj` is a motorbike) |
| `DebugCarCover` | `0` | test hook: DebugTestCar parks its car empty instead, facing north with its left side 0.9 m east of the player and the middle of its bonnet level with him, and a ped stands just beyond its right side there (for `tools/fake_minecraft.py --pick-test`: Minecraft's hits over the bonnet must reach him) |
| `DebugBulletWall` | `0` | test hook: N s into play, a ped with a pistol stands 1.5 m to the player's right and another 6 m ahead, and the first keeps shooting at the second (with a wall of blocks between them its shots stop at the wall: the `bullets` stats line, the second ped's health) |
| `DebugFireworkTargets` | `0` | test hook: N s into puppet mode, targets in the direction the player looks: a police Maverick (police pilot) hovering `DebugFireworkHeliAhead` (40) m ahead and 18 m up (a quarter of any extra distance higher, turned or lifted to where GTA's map leaves it room), side on, held there until something hurts it, and 14 m ahead two peds standing still left of a spot and a parked Admiral right of it; logs their spots in Minecraft's coordinates (`DebugFireworkTargets: aim`, for an autorun's `summon firework_rocket` with a `Motion` toward them) and their health, wrecks and ragdolls as they change for 60 s |
| `DebugBumpPed` | `0` | test hook: N s into play, a ped stands still 3 m ahead of the player (to run, fall or glide into: `tools/fake_minecraft.py --charge`, or an autorun's `tp` above it); its health, ragdoll and position are logged every second for 20 s |
| `DebugDieInCarAB` | `0` | test hook: killing blows on vehicle occupants cycle through the ways of dealing them (`DAMAGE_CHAR`, `EXPLODE_CHAR_HEAD`, `SET_CHAR_HEALTH 0`), and each killed occupant's pelvis is logged in the car's frame 0.5, 1.5 and 4 s later |
| `DebugKnockbackVariant` | `-1` | test hook: Minecraft's hits shove peds a different way each hit (0 world direction, 1 turned into the ped's frame, 2 the old flags, 3 no force), cycling from this one, and log how far along the push each went |
| `Render` | `1` | draw Minecraft's blocks and HUD in GTA's frame (0: only drain the render ring) |
| `RenderCamera` | `auto` | the blocks' camera: `auto` (the render phase's grcViewport, else the final cam), `phase`, `current` (grcViewport::sm_pCurrent), `finalcam` |
| `RenderDepth` | `auto` | GTA's depth buffer: `auto` (logarithmic when FusionFix is loaded, else standard), `log`, `standard`, `off` (blocks not hidden by GTA's world) |
| `RenderBehindGlass` | `1` | GTA's glass (vehicle and shop windows) doesn't hide the blocks and the body behind it: they are tested against GTA's depth from before its transparent pass (see Rendering) |
| `RenderExposure` | `1.0` | brightness multiplier for the blocks (after GTA's tone mapping) |
| `RenderLighting` | `gta` | `gta`: GTA IV's sun, ambient, fog and tone mapping (see Rendering); `minecraft`: Minecraft's own light levels |
| `RenderSaturation` | `0.8` | colour saturation of the blocks when GTA's tone mapping constants are unavailable (else GTA's own) |
| `RenderShadows` | `1` | sun shadows: the blocks take GTA IV's and cast their own onto themselves and GTA's world (see Rendering) |
| `RenderShadowStrength` | `1.0` | how dark GTA's world gets in the blocks' shadow (1: as GTA shades its own; 0: the blocks shade only blocks) |
| `RenderShadowBias`, `RenderShadowDistance`, `RenderShadowCast` | `0.05`, `128`, `1` | not in the default ini: metres the blocks' casting surfaces move away from the sun (against acne), how far from the camera blocks cast (m), and `0`: the blocks only take GTA's shadows |
| `DebugShadows`, `DebugShadowsAB` | `0` | test hooks: log GTA's shadow constants (on changes and every 10 s) and write both atlases to `<gamedir>/libertycraft-shadow-gta.pgm` and `-ours.pgm` (15 s after the shadows come on, then every 30 s); `DebugShadowsAB=N` switches the shadows off and on every N s, logging `DebugShadowsAB: shadows on/off` |
| `DebugShadowView` | `0` | test hook: the blocks show their shadow term instead of their colour (red GTA's, green GTA's and the blocks', blue 0.5) |
| `DebugBehindGlassAB` | `0` | test hook: `N` s with `RenderBehindGlass` off, `N` s on, in turn (logged as `DebugBehindGlassAB: GTA's glass hides/shows ...`) |
| `DebugFrameTrace` | | test hook: e.g. `25,40`: GTA's device calls of one frame at each of those seconds after the blocks are first drawn (render targets, depth buffers, clears, render target and depth textures bound, the draws between counted by depth write and blending) to `<gamedir>/libertycraft-frametrace-N.txt` |
| `DebugShadowSpot` | | test hook: `x,y,z,heading` (GTA), 12 s after the blocks are first drawn put the player there once (e.g. `1191.6,202.6,32.5,149`, the sunny sidewalk outside Schottler Medical Center) |
| `RenderExposureKey`, `RenderExposureFloor` | `0.85`, `11` | calibration of the auto exposure stand-in (not in the default ini) |
| `DebugTimeOfDay`, `DebugWeather`, `DebugStepSeconds` | | test hooks: pin GTA's clock to each hour of a list in turn (e.g. `12,19.5,21.5,0`) and force each weather of a list (`-1` leaves it; 0 extrasunny, 3 cloudy, 4 rain, 6 foggy), one step every `DebugStepSeconds` (20) once the blocks are drawn; logs `debug step i/n` |
| `DebugLightingAB`, `DebugLighting` | `0` | test hooks: alternate Minecraft's and GTA's lighting within each step; log GTA's lighting registers and the sun/ambient sets per step |
| `Overlay` | `auto` | Minecraft's HUD: `auto` (while puppeting or a Minecraft screen is open), `always` (whenever Minecraft is alive), `off` |
| `VehicleKey` | `F` | while Minecraft drives: GTA enters/steals the nearest vehicle (see Vehicles and Niko mode) |
| `ToggleKey` | `Backslash` | Minecraft mode <-> Niko mode. Key names: a letter, digit, F1-F12, `Backslash`, `Grave`, `Tab`, `Minus`, `Equals`, `LBracket`, `RBracket`, `Semicolon`, `Apostrophe`, `Comma`, `Period`, `Slash`, `Space`, `Insert`, `Delete`, `Home`, `End`, `PageUp`, `PageDown`, `Numpad0`-`9`, ... or a DIK code like `0x2B` |
| `HideNikoInVehicle` | `1` | hide Niko in vehicles in Minecraft mode (Minecraft's player rides its mount there) |
| `ToggleStartsInMinecraft` | `1` | start in Minecraft mode (0: Niko mode) |
| `VehicleSeatDrop` | `0.75` | metres from the seated ped's position down to the riding Minecraft player's feet |
| `VehicleEnterFallback` | `warp` | GTA's enter press didn't take within 2 s: `warp` (`WARP_CHAR_INTO_CAR`, closest car within 10 m), `task` (`TASK_ENTER_CAR_AS_DRIVER`), `none` |
| `DebugAutoToggle` | `0` | test hook (not in the default ini): toggle the mode every 10 s |
| `DebugAutoVehicle` | `0` | test hook: press the vehicle key when a car is within 12 m (else park an empty test car next to Niko first; indoors, move him to the nearest road), and GTA's exit control after 12 s in a car |
| `DebugVehicleDriver` | `0` | test hook: DebugAutoVehicle's test car gets a random driver (the press carjacks) |
| `DebugInjectEnterKey` | `0` | test hook: the vehicle key's taps as real key events (`SendInput`) instead of pad writes |
| `PhoneKeys` | `1` | GTA's phone in Minecraft mode: the arrow keys are GTA's, and Enter, Backspace and the number keys while the phone is out (see Input while puppeting) |
| `DebugPhone` | `0` | test hook: real key events that log which pad controls some keys feed, then take the phone out, open the phone book, scroll and put it away |
| `PuppetMove` | `direct` | how the puppeted ped is placed: `direct` (the natives' own move without their clearing, see Conventions) or `native` (`SET_CHAR_COORDINATES_NO_OFFSET`: deletes the cars and peds the player walks into) |
| `DebugWalkThroughCar` | `0` | test hook: walks the puppet target through a parked (ambient) car and into a pedestrian, once with each move method, and logs whether they survive |
| `DebugFocusCycle` | `0` | test hook: a window of the plugin's own takes the foreground for 3 s and gives it back, twice (alt-tab without a keyboard); SendInput mouse moves before and after show whether raw mouse input still arrives. The first cycle runs without the raw mouse watchdog |
| `RagdollOnVehicleHit` | `1` | any vehicle running into the puppeted player knocks them over: GTA takes Niko, ragdolls him along the vehicle's way and keeps him until he is back up; the hit hurts the Minecraft player (2.5 GTA damage per m/s / `PlayerDamageScale`, helicopters, planes and trains 1.5 times that, plus what GTA does to him while he tumbles). Cars, bikes, boats and trains are their model box; a helicopter's or plane's body is measured once per model with line probes against its collision (as slabs along its length: the cabin, the thin tail boom; not the rotor disc that its model box spans). What counts is the speed of the vehicle's point where the player is, from its pose this frame and last (its motion, its turning, up and down): 3 m/s or more (helicopters, planes, trains 2), into the player (not a vehicle pulling away from him), so a helicopter coming down on him or its tail swinging round hits like a bumper. A helicopter's spinning rotors (main and tail, hubs from the vehicle structure's bones, spin measured from the moving rotor bone) strike the player where his column crosses their disc: 180 GTA damage (18 Minecraft, tail 120) and a hard fling out from the hub (16 m/s, tail 12), and he falls invincible for 1 s (GTA's own rotor would chop him for 660 more). One of GTA's explosions hurting the puppeted player (20+ health) does the same, away from what blew up. The throw matches GTA's own run-over (`DebugVehicleHit=ped`: a pedestrian hit by a car at 10.1 m/s went off at 8.8 m/s and came to rest 10.9 m away): he is first moved out of the vehicle's box along the push (puppet mode leaves him frozen with collision off, so the vehicle is already into him when the hit is seen), clear of its next frames' travel (stopped short of the map), then ragdolled and pushed off at 0.87 of the vehicle's speed (1.15 times that for helicopters, planes and trains; at least 3.5 m/s). `APPLY_FORCE_TO_PED` sends him off at 1.8 m/s per unit of force (measured: 12 -> 21 m/s, 19 -> 34 m/s); every knockdown's push is capped at 20 m/s. (The old forces, 2 per m/s, threw him 40 to 90 m.) Where each knockdown took him is logged (`came to rest N m from where he was hit`) |
| `MinecraftBody` | `1` | while GTA animates Niko, show the Minecraft body following his animation instead of him (master switch) |
| `MinecraftBodyCutscenes`, `MinecraftBodyVehicles`, `MinecraftBodyNikoMode` | `1`, `1`, `0` | ... in cutscenes; getting into, driving, bailing out of and getting out of vehicles (0: Niko as before, the Minecraft player on its mount in the seat); in Niko mode. Knockdowns follow `MinecraftBody` alone |
| `MinecraftBodyScale` | `1.0` | the body's size on top of the automatic fit (Minecraft's own proportions at Niko's height, the feet on the ground; seated 0.76 of Minecraft's size, the hips on the seat; never with its head over his); 0.5 to 2 |
| `MinecraftBodyHide` | `visible` | not in the default ini: how a ped under the body is hidden, `visible` (`SET_CHAR_VISIBLE`, every frame) or `alpha` (`SET_PED_ALPHA` 0) |
| `MinecraftBodyProps` | `1` | not in the default ini: what Niko holds or carries (the bowling ball, a bag, his phone) stays visible under the body (0: hidden with him, as before) |
| `DebugBody` | `0` | test hook: log the skeleton once a second (bones, limb motion, ankle heights, the size and how much it sits; seated in a vehicle where the pelvis bone is in it against the ped's position this frame and last) and, in cutscenes, the animated objects around the camera |
| `DebugBodyView`, `DebugBodyViewSeconds` | | test hook: while GTA drives the player, the camera looks at the body's hips (or the player) from these views in turn, `angle,distance,height` (degrees counter-clockwise from his front, 90 his left side; metres) separated by `\|`, `DebugBodyViewSeconds` (5) each; logs `DebugBodyView: view i` at each change |
| `DebugBodyAB` | `0` | test hook: N s with the Minecraft body, N s without it (Niko, or Minecraft's rider), in turn (`DebugBodyAB: A/B`) |
| `DebugTrainRide` | `0` | test hook: the nearest train carriage logged every 2 s, and N s into play the player is put into it as a passenger (`WARP_CHAR_INTO_CAR_AS_PASSENGER`); then the ride is logged. `DebugTrainSpot=x,y,z,config`: no train within 200 m by then, a mission train is made on that track point (`CREATE_MISSION_TRAIN`; the tracks are `common/data/paths/Tracks*.dat`, e.g. `906.925,-501.617,24.5798,0` on the El beside Roman's flat) |
| `DebugInputScript` | | test hook: input events for Minecraft at set times after puppet mode first starts, `\|` separated `seconds:kSCANCODE:1` (an SDL key down, `:0` up) or `seconds:mBUTTON:1` (an SDL mouse button: 3 is the right one); `Pseconds:...` counts from when GTA's phone first came out; `seconds:vYAW:PITCH` turns the look (Minecraft degrees: yaw 0 south, -90 east; pitch down positive), `seconds:aYAW:PITCH` sets it, as Minecraft's look follows GTA's mouse look and a `/tp ... facing` doesn't hold |
| `DebugSeatedHurt` | | test hook: GTA hurts the player in a vehicle in Minecraft mode, a comma list of steps run in turn from 20 s into puppet mode, each after he is put in a car unless he sits in one (an Admiral parked beside him and the vehicle key; indoors he goes to the street first): `shoot` (two peds with Micro Uzis 4 m off the driver's door and off the front left corner fire at him for 10 s), `crash` (his car turned to the nearest wall of GTA's map 8 to 45 m away and driven into it at 30 m/s), `explode` (`EXPLODE_CAR`), `exit` (`TASK_LEAVE_ANY_CAR`, until puppet mode has him again), `niko` (Niko mode for 3.5 s of `shoot`, then Minecraft mode), `jack` (a ped by the driver's door is told to get in as the driver), `fight` (an unarmed ped there fights him), `jack-` and `fight-` (the same with `SET_CHAR_CANT_BE_DRAGGED_OUT` off, to compare), `owner` (first, on foot: the car has a driver, the vehicle key carjacks him, then 12 s seated), `cops` (3 wanted stars for 35 s), `nikodie` (Niko mode and the shooters until GTA kills Niko), `heal` (`kInRestore`). Each step ends with a `DebugSeatedHurt:` line (the `kInHurt` sent, GTA's and Minecraft's health, who owns it, what GTA's HUD shows); after a death the steps go on 10 s after the respawn; `DebugSeatedHurt: done` at the end |
| `DebugBailOut`, `DebugRunOver` | `0` | test hooks: DebugAutoVehicle's car drives off at 14 m/s and Niko bails out of it 2 s later; every 40 s of puppeting (outdoors; else moved to the road) a test car 15 m up the road drives at the player at 12 m/s |
| `DebugVehicleHit` | | test hook: a comma list of `heli` (a Maverick flies at the player at 8 m/s, a little off the ground), `drop` (one 9 m over him comes down at 4 m/s), `rotor` (one creeps at him at 3 m/s until its hub is 2.5 m away: stand him on something about 3 m up, its rotor reaches him first), `bike` (a PCJ at 12 m/s), `car` (an Admiral at 10 m/s; `car-old`: his knockdown dealt the old way, in place; `car-gta`: moved clear, then the car's own collision knocks him down), `ped` (GTA's own run-over to compare with: a pedestrian stands still 9 m ahead of the camera, 3 m to the right, and an Admiral comes at it from 15 m beyond at 10 m/s; where it comes to rest is logged), run one after another from 30 s into puppet mode, ahead of the camera; the cars drive on unpushed once they touch him; each vehicle is logged every 0.25 s (distance, velocity, rotor spin) and deleted 8 s on |
| `DebugCutscene` | | test hook: play this cutscene (e.g. `intro`, `rom2_a`; names from `pc/anim/cuts.img`) 20 s into puppet mode; its camera is logged every 2 s. What the game's own script sets up first isn't done: `intro`'s ship never appears (its people float over the sea; `LOAD_SCENE` at the cutscene's camera, 1.5 km from the player, didn't bring it), and `rom1_a` didn't load within 30 s |
| `ScriptScenes` | `1` | a mission script that takes the player over on foot (his control off, its camera, a task on him, a minigame) gets him: GTA IV drives him until it lets go, with GTA's camera and pad and the Minecraft body on Niko (see Mission scripts; 0: puppet mode fights the script, as before) |
| `MissionPedsSafe` | `1` | Minecraft's mobs leave mission characters and the vehicles they sit in alone (`kActorMission`: no hunting them, no mob's hit or blast reaches them), and they never fight or flee mobs (MobFight) |
| `ScenesPauseMinecraft` | `1` | GTA's cutscenes and the scripts' cameras pause Minecraft like GTA's pause menu (`kSkyScene`: its mobs, their blasts and its sounds stand still, hostile mobs aren't drawn) |
| `ContextActions`, `ContextKey` | `1`, `E` | GTA's context actions work in Minecraft mode: while GTA's help box asks for `~INPUT_PICKUP~` ("Press E if you want to bowl", "to buy a hotdog", "to play pool", "to open the cash register"), puppet mode lets that control through to GTA and `ContextKey` goes to GTA instead of Minecraft (no inventory then); see Mission scripts |
| `DebugMissionProbe`, `DebugMissionProbeAB` | `0`, `0` | test hooks: N s into play (on foot) a mission scene as a script plays one: `TASK_GO_STRAIGHT_TO_COORD` 4 m ahead (12 s at most: a script waiting for it), the control off for 3 s, a script camera in front of the player for 4 s, `SET_MINIGAME_IN_PROGRESS` for 3 s, each logged (`DebugMissionProbe: ...`, `SCREENSHOT` lines for a watcher); `AB`: twice, first with `ScriptScenes` off, then on |
| `DebugMissionBlips`, `DebugMissionWarp` | `0`, | test hooks: the radar's blips logged once 10 s into play (sprite, colour, place: where the contacts' missions start); the player put at the nearest blip of these contacts 20 s into play (5 s after `DebugMissionProbe`), e.g. `roman,vlad,jacob` or `any`, his control off from 1 s before to 1.5 s after as a script warps him (so in Minecraft mode GTA has him meanwhile) |
| `DebugPhoneCall` | `0` | test hook: N s into play, 6 s of `kSkyPhoneCall` (Minecraft's sounds duck) without a call in GTA |
| `DebugContextKey`, `DebugFakePrompt`, `DebugProp` | `0`, `0`, | test hooks: `ContextKey` pressed (a real key event, 0.15 s) 1.5 s into the first context action offered while puppeting, with the pad's `INPUT_PICKUP` logged as scripts read it (`IS_CONTROL_PRESSED`); N s into puppet mode GTA's help box shows "Press ~INPUT_PICKUP~ to test the context key." through the game's own setter (0x8ABA20, what `PRINT_HELP` calls; checked); 10 s into play an object of this model (e.g. `cj_bowling_ball3`) on Niko's right hand during a 6 s scene (his control off), a `SCREENSHOT` line in it |
| `DebugViewportRoom` | `0` | test hook: `1` logs the room GTA renders from against the camera's place every 0.25 s near interiors (`ViewportRoom`); `2` also switches the correction off and on every 8 s |
| `DebugGiveWeapon` | `0` | test hook: give Niko this GTA weapon (7 pistol) 10 s into play (puppet mode puts it away, Niko mode gives it back) |
| `HazardsBurnPeds` | `1` | Minecraft's fire and lava (soul fire, lit campfires too) set GTA's peds on foot alight and hurt them like Minecraft's own (2 and 8 Minecraft damage a second, magma 1, x `PedDamageScale`); out of it they burn on for 4 s (lava 8 s) and are put out. Niko too, unless Minecraft owns him (puppet mode, knocked over) |
| `HazardsBurnVehicles` | `1` | a vehicle on fire blocks loses 250 engine health a second (below 0: GTA's engine fire, and its explosion if it keeps burning), on magma 50; in lava it's set alight and wrecked in seconds. Traffic, parked cars and the player's own; their real model box |
| `LiquidsSlowVehicles` | `1` | vehicles struggle in Minecraft water and lava, the deeper the worse (about 8 m/s top in 0.2 m of water, 3 in 0.5, a crawl in 0.9); over a metre of water the engine runs on for 3 s, then stalls (held off while that deep, starts again out of it). Never damage from water |
| `LiquidsSlowPeds` | `1` | GTA's peds wade slower in Minecraft water (1 at ankle depth down to 0.35 of their speed) |
| `MinecraftWaterIsGtaWater` | `0` | not in the default ini, experimental: GTA's water level query (0x9AB6C0 on 1.0.8.0, hooked after a byte check) answers Minecraft's water surface where there is Minecraft water (not for scripts' `GET_WATER_HEIGHT*`, nor around the puppeted player). Measured: its callers are the camera, the player's position and a few effects; GTA's ped swimming and vehicle buoyancy don't use it |
| `DebugHazards` | `0` | test hook: to the street 15 s into puppet mode; every 15 s the nearest walking ped is put into Minecraft water near the player (its speed logged); every vehicle in Minecraft's blocks is logged (not just the player's); the player's stalled car is pulled back out of the water (twice), to see its engine start again; with the water hook, who asks it |
| `DebugHazardInject` | | test hook: `fire` / `lava`: a 3 x 3 patch of it (in the plugin only) under the nearest walking ped every 20 s; `harbour` / `shore`: 30 s into puppet mode a test car with Niko in it is dropped into GTA's own water (or set on the land before it, to drive in with `DebugDriveThrottle`) and GTA's own drowning is timed |
| `DebugPauseMenu`, `DebugPauseMenuCycles` | `0`, `3` | test hook: N s after the player is in game (with `DebugDriveWander`: seated) GTA's pause menu opens with a real Esc key event (`SendInput`, the keyboard's path; from a thread of its own), shows the map page for 8.5 s (`DebugPauseMenu: SCREENSHOT the map page` 6 s in) and closes with another; that many times. Each step logs the frontend's screen, whether its `frontend` texture dictionary loaded (`EMPTY`: the white map that crashed on closing) and the free address space; `frontend:` lines follow every change |
| `DebugDriveWander` | `0` | test hook: after 4 s on foot the player is put in an Admiral on the nearest road and GTA's AI drives it through the city at up to this many m/s (`TASK_CAR_DRIVE_WANDER`, style 2), logging its speed, place and the ped and vehicle pools' use every 5 s |
| `DebugDriveThrottle` | `0` | test hook: in a car, hold GTA's accelerator this many seconds (from 1 s in), the speed logged |
| `CityMaterials` | `1` | not in the default ini: collision triangles carry GTA's material of their surface (`kTriGtaMaterial`), so the blocky city builds tarmac, pavement, brick, glass, grass, ... out of the right blocks (0: Minecraft guesses from the kind of surface) |
| `DebugMaterials` | `0` | test hook: logs the line probes' unnamed result fields (histograms every 20000 hits, and some downward hits with where they hit): how the material was found |

## The blocky city (kMcBlockyCity)

A nether portal lit in the mirror world leads Minecraft's player into `libertycraft:blocky_city`, a
block copy of Liberty City at the same coordinates (1:1) that the mod builds from the collision this
plugin streams (it keeps every region it receives, see the root README). Everything stays in GTA IV:
Minecraft stays hidden and linked, puppet mode, teleports, combat and vehicles go on, and the city's
blocks arrive through the render ring like any others (a level change makes the mod send
`kRenClearAll` and the new dimension's sections, so nothing of the mirror world stays drawn).
McState carries `kMcBlockyCity`, and `BlockyCity.*` hides GTA's own map geometry meanwhile, so the
blocks are the city around Niko:

- every frame, every building in the building pool (map sections, terrain, interiors and their
  LODs) and every loose object in the object pool that belongs to the map (street furniture, props,
  doors; not weapons, pickups, vehicle or ped parts, nor anything attached to a ped or a car) gets
  its visible flag (`CEntity` `+0x24` bit 5) and its cast-shadows flag (`+0x28` `0x80`) cleared, so
  what streams in while the player walks around disappears too; the sky, the water surface, peds,
  vehicles and the HUD stay. The scan is logged every 10 s with its cost;
- back in the mirror world (the bit clears) every entity hidden that is still there with the same
  model gets both flags back; a game load forgets the list; the 10 s line also gives how much of the
  game's 32-bit address space is in use (the blocks' vertex buffers are `D3DPOOL_MANAGED`: a copy of
  each stays in the game's memory). Minecraft draws the city further out than the mirror world
  (`blockyCityRenderDistance`) and drops a chunk's sections here when it unloads it (an empty
  `kRenSection` and empty lights, solids and liquids), so only the city near the player is held.
  Measured at 16 chunks in Broker (an area of about 400 x 400 m explored): 646 sections, 46.8 MiB of
  vertex buffers, 1.7 M triangles in view, 0.43 ms a frame to draw them, and the address space in
  use stayed at 2089 of 4095 MiB. The default is 12 chunks: dense parts of Algonquin stack many more
  sections per column than Broker;
- GTA's collision isn't touched: it is the same city, so its peds and cars walk and drive on it. The
  city's own blocks therefore don't come in `kRenSolids` / `kRenLiquids` (the mod compares each
  block with what the city's generator put there), so `NpcBlocks` and `Hazards` see only what the
  player built in the city.

The blocky city's blocks come from the triangles' materials (`kTriGtaMaterial`). The material of a
line probe's hit is the low byte of the `tLineOfSightResults` dword at `+0x48`, its index in
`common/data/materials/materials.dat` (0 `DEFAULT` ... 155): measured with `DebugMaterials` on
1.0.8.0, the street gave 8 `TARMAC`, the pavement 3 `CONCRETE` and 16 `PAVING_SLABS`, a roof 54
`LEAD_ROOFING`, Roman's flat 87 `CARPET`, 86 `LINOLEUM` and 20 `WOOD_BOARD`. The bytes above it hold
other things (`0x0001xxxx`, `0x0060xxxx`, `0x02xxxxxx` seen); `+0x4C` looks like the polygon (or
component) index, `+0x50` was always 1. Floors and ceilings take the material most of their corner
samples were probed on, walls their probe's hit; walls found only from the far sample's solid and
street furniture (object probes) carry none.

## Vehicles and Niko mode

GTA IV takes the player back from Minecraft (`kSkyHostDrives`: Minecraft follows `SkyState`
pos/yaw with no physics, input or damage) when:

- **Niko mode** (`ToggleKey`, Backslash): plain GTA IV. No puppet, no input for Minecraft, GTA's
  HUD and mouse; Minecraft's player follows Niko. The toggle key works in both modes (it is
  never forwarded) and shows a short on-screen note. Back in Minecraft mode the teleport
  handshake runs at Niko's spot, then puppet mode.
- **`VehicleKey`** (F) while puppeting (never forwarded to Minecraft): puppet mode lets go and
  `processPadEvent` taps GTA's own `INPUT_ENTER`, so the game picks the door or carjacks as
  usual. GTA's enter check (1.0.8.0: `0xA60D0B`) only takes the press while the ped counts as
  standing (CPed flag word `0x26C` bit 0, set by the ped's ground probe), and every puppet frame's
  move clears that flag: after puppet mode lets go Niko stands again 0.1 to 0.5 s later. The old
  single press came before that and was lost, so the player's second F (GTA's own) did it. The
  taps (0.1 s each, up to 3, 0.45 s apart) start once GTA reads the player's pad again and Niko
  stands (at most 0.75 s), and stop as soon as Niko walks off to a door or is getting in (then
  no fallback while he walks). Releasing the ped also sets it down onto the ground when it hangs
  up to 0.3 m above its resting height (Minecraft's feet often sit a few cm higher than GTA's
  physics rests Niko): a ped that drops even a few cm is "landing" for over a second, and GTA
  ignores F meanwhile. A synthetic tap behaves like a real F (`DebugInjectEnterKey`): where
  GTA itself won't enter (some spots next to a car), the fallback does. No "getting in" after 2 s:
  `VehicleEnterFallback`. No vehicle after 4 s: back to Minecraft.
- **in a vehicle** (`IS_CHAR_IN_ANY_CAR`, however Niko got there: the key, a mission script, a
  cutscene): GTA drives, its own F gets out. `SkyState` also carries `kSkyInVehicle`, pos = the
  riding player's feet (ped position - `VehicleSeatDrop`), yaw = the vehicle heading; Minecraft
  puts its player on a mount there (a boat by default). Niko is hidden (`HideNikoInVehicle`), or
  the Minecraft body sits in his place (`MinecraftBodyVehicles`, below). On foot again and standing
  (getting back up, below): the teleport handshake, then puppet mode. While the Minecraft player is
  in creative or spectator (McState `kMcCreative`: nothing hurts it) GTA's peds can't drag him out
  of it in Minecraft mode (`SET_CHAR_CANT_BE_DRAGGED_OUT` while seated; survival and adventure keep
  GTA's own dragging, Niko mode and getting out clear it). Without it (`DebugSeatedHurt`) any ped
  fighting him (those `GtaCrimes` sets on him: an unarmed one pulled him out of a stopped car 3.6 s
  after being told to fight him) and any ped told to take the car did; with it they stand at the
  door (20 s each, measured). A drag-out attempt is logged with the ped's type (`a ped tries to
  drag the player out`).
- getting into a vehicle (`IS_CHAR_GETTING_IN_TO_A_CAR`, e.g. a mission script) and cutscenes.
- **a mission script's scene** on foot (`ScriptScenes`): see Mission scripts below.
- **getting back up**: out of a vehicle (a bail-out from a moving car rolls and tumbles), knocked
  over (`RagdollOnVehicleHit`) or ragdolled by GTA in Minecraft mode, GTA keeps Niko until he
  really stands: on his feet (`IS_PED_RAGDOLL`, `IS_CHAR_GETTING_UP`, `IS_CHAR_IN_AIR` all false,
  `GET_CHAR_SPEED` under 0.5 m/s, GTA's own standing flag) for 0.4 s, at least 0.5 s on foot, at
  most 8 s. A knockdown is applied once puppet mode has let go of him (`SWITCH_PED_TO_RAGDOLL`,
  then `APPLY_FORCE_TO_PED` in world axes, as Combat measured; a vehicle's moves him out of its box
  first, see `RagdollOnVehicleHit`); while knocked over Minecraft
  still owns his health (Combat's buffer), so GTA damage meanwhile goes to Minecraft and GTA can't
  kill him. While he gets back up (on foot) the player's input isn't GTA's (`padLocked`: his pad
  is cleared as in puppet mode, no aiming or firing his gun); only vehicles and Niko mode give GTA
  real player input. While the screen fades (a cutscene's end, a script's warp: not in game for
  DriveLogic) the body stays as it was, the cutscene's Niko kept shrunk; at a cutscene's end the
  full-size Niko showed for a frame before. Handing back, the body stays on him (and he hidden) until puppet mode has
  him, so no frame shows Niko in between.
- **the player's health in vehicles**: Minecraft owns it there too in Minecraft mode, from the
  vehicle key's walk to the door through the seat to getting back up after getting out or bailing
  out (`HostDrive::VehicleInMinecraftMode`, Combat's buffer; no hand-back and no jump in between).
  GTA's damage there (gunfire, a crash, flying through the windscreen and the tumble after it,
  fire) goes to Minecraft as `kInHurt`, so a creative player is immortal in a car and a survival
  player loses hearts and dies in Minecraft (then GTA's wasted flow, as on foot). Falls count while
  GTA moves him (Minecraft only follows then); GTA's explosions don't knock a seated player over.
  GTA IV kills a vehicle's occupants outright when it blows up (`EXPLODE_CAR` took the buffer from
  1000 to 0 within the native, and he died in creative): seated, he is explosion-proof instead,
  and the blow-up reaches Minecraft as a point-blank blast's worth (400 GTA damage, 40 Minecraft
  at `PlayerDamageScale=10`), so Minecraft decides (creative takes nothing, armour and a totem
  count). GTA's HUD shows Minecraft's health and armour in vehicles as on foot. Niko mode gives GTA
  his own health back (what he had when Minecraft took over), so there GTA's damage is Niko's.
  Minecraft lets these hits through while GTA drives its player (`HostDrive.applyingHostHurt`);
  nothing else can hurt it then.

**The Minecraft body** (`MinecraftBody`, `NikoBody.*`, `render/Body.h`): while GTA drives for one
of the reasons above (per `MinecraftBodyCutscenes` / `Vehicles` / `NikoMode`), Niko is hidden
(`SET_CHAR_VISIBLE` every frame, also right after leaving puppet mode, which shows him) and the
standing body Minecraft sends (`kRenRagdoll`: parts tagged per model part, held items on their
arm; re-sent at once when the skin, armour or held items change) is drawn instead of the avatar,
each part posed by his bones as `drawingEvent` reads them (`GET_PED_BONE_POSITION`; offsets give
the head bone's axes): the body leans with hips -> neck and the shoulder line, legs point from
Minecraft's hips at his soles, arms from Minecraft's shoulders at his hands (hands on the wheel),
the head turns with his head bone (x up the neck, y forward, z left; checked once by
`CalibrateHead`), and the figure moves so its lower sole meets his. Sizes: the figure keeps
Minecraft's own proportions, every part scaled alike (never stretched to his bones: his legs are
longer than a Minecraft player's, his head half the size), to his height standing (1.77 m: 0.94 of
Minecraft's 1.875 m), so its hips sit lower than his. Seated (a car seat, a chair or a sofa in a
cutscene: both thighs raised 40 to 70 degrees from the pelvis's down line, eased over about 0.2 s)
the Minecraft torso and head would rise 0.25 m over his head (his hips to the top of his head are
0.86 m, Minecraft's 1.17 m): seated the figure is 0.76 of Minecraft's size instead, its hips on his
seat and its head under the roof, the legs dangling short of the floor. Whatever the pose, the top of
its head never goes more than 3 cm over his: the figure sinks instead. All times
`MinecraftBodyScale`. Cutscenes: GTA IV's cutscene
Niko is no ped but an animated object of the player's model (object pool); its bones come from
the game's own bone matrix function (1.0.8.0: `0x941E30`, code bytes checked) after
`CDynamicEntity::GetBoneMatrix` waits for its pose job. The game only poses what it draws, so it
can't be made invisible (invisible, it stops moving; an alpha of 0 fades back in by 16 a frame, a
ghost over the body): its matrix is shrunk to 5% instead (a doll a few centimetres tall inside the
body, its bones scaled back up when read; it keeps that size when the cutscene ends or the screen fades,
or the full-size Niko showed for a frame before the cutscene removed him). Peds keep animating while
invisible (measured).
Seated in a vehicle (`IS_CHAR_IN_ANY_CAR`) the held items are hidden (collapsed onto the hand:
`Pose::part[kPartNone]`, which no batch uses, places them before their arm does), as the sword
and shield poked through the roof; so they are while GTA's phone is out (his hand holds the phone,
not the pickaxe at his ear). GTA's camera at the body (a helicopter coming down pushed it in
between the wall and the body, which is bulkier than Niko): knocked over, with GTA's own camera
within its near plane + 0.3 m of any part's box (with the outer skin layer and armour) the whole
body is hidden for that frame, as GTA fades its own player; in vehicles (a train ride's cameras
come close) only the parts within that of it go, and a cutscene's camera (close-ups) only hides the
parts it is in or within its near plane + 0.1 m of (`camera at (or in) the Minecraft body` in the
log); a mission scene's counts as a cutscene's while a script's camera shows it, else as GTA's own.
What Niko holds or carries stays visible under the body (the bowling ball, a bag, his phone): hiding him
hides it too (CPed's SetVisible, vtable +0x30 = 0x93B8E0 on 1.0.8.0, checked, passes it on to the four
entities at CPed +0xD68), and objects a script attached to him (`m_pAttachedToEntity`) are drawn with him;
`NikoBody::Hide` shows those again (`N prop(s) Niko holds or carries shown under the Minecraft body`;
`DebugProp=cj_bowling_ball3` with `DebugBodyView`: the ball at the body's hand, gone with `MinecraftBodyProps=0`).
Puppet mode's own hiding (first person) leaves them hidden.

`Game::State()` exposes `hostDrives`, `inVehicle` and `nikoMode` for the renderer and overlay.
The decisions are `DriveLogic.h` (pure, tested by `asi/tests/drive_test.cpp`).

## Mission scripts (Missions, drive/SceneLogic.h)

GTA IV's mission scripts play their on-foot scenes with the player's own ped: they switch his control
off, show a camera of their own, give him tasks (walk to a mark, follow someone, play an animation)
and wait for them, or run a minigame that reads his pad (bowling). Puppet mode fought all of that: it
put his control back on every 0.5 s, drew Minecraft's camera over the script's, zeroed the pad the
minigame read, and every puppet move cleared his tasks before they ran (a scripted task is an event
the ped's intelligence turns into his primary task on its next update), so the scripts waited forever.
With `ScriptScenes=1` GTA IV drives the player while any of these holds (`Why::kScript`, as in Niko
mode: no puppet, GTA's camera and pad, keys and mouse are GTA's, the Minecraft body on Niko under
`MinecraftBodyCutscenes`, Minecraft's HUD hidden, Minecraft's player follows him), read from the game
every frame before the puppet decision (1.0.8.0; each address is read from code that is checked first):

- **his control off by a script**: the player's control flags (`CPlayerInfo` +0x4BC; `IS_PLAYER_CONTROL_ON`
  is "all clear") have `SET_PLAYER_CONTROL`'s bit 0x20 (0x8B5C80) or `MAKE_PLAYER_SAFE_FOR_CUTSCENE`'s
  0x80. The game's own bits (0x1, 0x4, 0x200, 0x400, 0x2000; 0x800 and 0x1000 are network ones) don't
  count. Puppet mode no longer turns a script's control-off back on, and leaving puppet mode for a scene
  leaves the control, GTA's HUD and the protection GTA gives a player without control as the script set them.
- **a script's camera**: the byte `ACTIVATE_SCRIPTED_CAMS`'s queued command keeps its first argument in
  (0x11C738A, written at 0x84574A); our own `CameraMode=scripted` camera doesn't count.
- **a script task on him**: the type of the task a `TASK_*` native gave him, a word at his
  intelligence +0x2EC (-1: none; the status byte follows, what `GET_SCRIPT_TASK_STATUS` reads; 0x96E0D0
  is the game's own test). Set at once by the native, before his intelligence runs it.
- **a minigame**: `IS_MINIGAME_IN_PROGRESS`'s counter (0x120A680).

Signals that come and go between the shots of one scene (a camera cut, one task ending as the next
starts, the script's own frames between a cutscene's sections) don't hand him back and forth: Minecraft
takes him back once all of them have been clear for 0.75 s (`SceneLogic::kReleaseSeconds`), with the
teleport handshake at his spot. In a vehicle the vehicle rules hold, in Niko mode nothing changes, and a
cutscene (`CCutsceneMgr`) keeps its own reason. Logged as `a mission script has the player (player
control off, the script's camera, ...)` and `the mission script let go of the player`; every change of
what the game says is a `mission state:` line (control flags, script camera, minigames, script task and
status, cutscene, phone call, on a mission).

**Context actions** (`ContextActions=1`): GTA offers them in its help box, "Press ~INPUT_PICKUP~ if you want
to bowl" (the token in the GXT text; 258 of them use `INPUT_PICKUP`, E on the keyboard, among them bowling,
darts, pool, QUB3D, food vendors and restaurants, shops' exits). The box (0xF38668, what `PRINT_HELP` fills)
shows while its +0x9A8 isn't 0 (`IS_HELP_MESSAGE_BEING_DISPLAYED`, 0x8AAEB0), its text (UTF-16, tokens as in
the GXT) is at +0x4B0 (`IS_THIS_HELP_MESSAGE_BEING_DISPLAYED`, 0x8AAFCA). While it asks for `INPUT_PICKUP` and
Minecraft drives, Input's pad zeroing lets that control through and `ContextKey` (E) goes to GTA, not to
Minecraft's inventory (`drive/Prompt.h`, tested). Once the script reacts it switches the control off or shows
its camera, and the takeover above has the player. Logged as `GTA's help text: "..." (asks for INPUT_PICKUP)`,
`a context action is offered` and `context key pressed: to GTA`. Measured (`DebugFakePrompt`,
`DebugContextKey`): the key down, GTA's pad read `INPUT_PICKUP` down in the same frame, with puppet mode on and
no Minecraft screen opened; the box's key glyph turned to E.

**Scenes pause Minecraft** (`ScenesPauseMinecraft=1`): while GTA shows a cutscene or a script's camera
(held 0.4 s over cuts, and through a cutscene's fade-out) SkyState carries `kSkyScene`, and the mod pauses a singleplayer world as for GTA's
pause menu (`GtaMenuPause`: its mobs, their blasts, its sounds and music stand still) and draws no hostile
mob into GTA's picture; whatever Minecraft's mobs still do meanwhile (a world open to friends runs on) is
dropped by Combat. During a **phone call** (`IS_MOBILE_PHONE_CALL_ONGOING`, `kSkyPhoneCall`) Minecraft's
sounds duck to a quarter of their volume, faded over 0.3 s (`SoundDuck`, a gain on top of the player's
volume options).

**Mission characters** (`MissionPedsSafe=1`): a ped a mission script owns (`m_nCreatedBy` 2, what
`IS_PED_A_MISSION_PED` tests) goes to Minecraft with `kActorMission`, as does every piece of a vehicle one
sits in (or of a mission's own vehicle someone sits in, `IS_CAR_A_MISSION_CAR`). Minecraft's mobs never
pick them as targets (`PedTargets`, `canBeSeenAsEnemy`), a mob's blow, arrow or blast on their stand-in
does nothing, Combat drops a mob's hit on one, and before one of Minecraft's mobs' blasts is set off in
GTA every mission character, their vehicles and a mission's own cars (`IS_CAR_A_MISSION_CAR`, empty too: a
creeper blew up the car Jacob's mission needed) within its radius + 4 m are explosion-proof for 2 s (their
own proof flag comes back after; `a Minecraft mob's blast ...: N mission character(s) ... explosion-proof`).
MobFight never tells a mission character to shoot at or run from a mob, nor its driver to drive off. The
player's own hits still count.

## Input while puppeting

Keys go to Minecraft as SDL3 scancodes (hardware scancode -> DirectInput code -> SDL). Esc and
`` ` `` stay GTA's (pause menu) unless a Minecraft screen is open; F1-F12 go to both. `MenuKey`
sends `kInOpenMenu`. Mouse: raw input (`WM_INPUT`) for look / the GUI cursor, buttons and wheel
from window messages. GTA reads DirectInput itself and the player keeps player control while
puppeted (`PuppetPlayerControl`), so `processPadEvent` clears every CPad control except
`INPUT_FRONTEND_PAUSE` and, with `PhoneKeys`, the phone's (below): buttons to 0, the axis controls
(move, look, mouse, frontend and vehicle axes, sniper zoom) to their rest value 128 (measured: 0 is
a full push, and with player control on Niko walked off while getting back up). The same while
Niko gets back up (above). Niko is hidden in every Minecraft camera mode (F5 too: Minecraft's body
is drawn there), every frame. GTA's weapon is put away while puppeting (its HUD showed Niko's
pistol next to Minecraft's sword; one a script hands him too) and comes back in Niko mode; in a
vehicle in Minecraft mode too (GTA picked the pistol for drive-bys there and its HUD showed it
next to the hotbar), and drive-bys are off (`SET_PLAYER_CAN_DO_DRIVE_BY`) until Niko mode. While GTA
drives the player (`HostDriveClient.driving()`) Minecraft draws no first-person hands or held items
into the overlay (`GameRendererHandMixin`), and its HUD keeps only the hotbar (selected item,
offhand), the hearts and the food bar (`HudWhileGtaDrivesMixin`: no crosshair or attack indicator,
armour, experience/locator/jump bar and level, air, mount hearts, action bar such as "Press Left
Shift to dismount", titles, held item name, effects, boss bars or camera overlays; chat, the
scoreboard, subtitles and toasts stay); the host draws no crosshair invert pass then either
(`kFrameCrosshair` needs puppet mode). Focus loss and GTA menus send
`kInReleaseAll`.

GTA's phone (`PhoneKeys=1`, the default) works like in plain GTA IV: Up takes it out (or answers a
call), the arrows navigate, Enter selects, Backspace goes back and finally puts it away. The arrow
keys are always GTA's; while the phone is out Enter, Backspace and the number keys are GTA's too
(Minecraft gets none of them then, only key-ups). In the pad, measured with `DebugPhone`: Up feeds
`PHONE_TAKE_OUT`, `FRONTEND_UP`, `KB_UP`; the other arrows the matching `FRONTEND_`/`KB_` controls;
Enter `FRONTEND_ACCEPT` and `KB_PHONE_ACCEPT`; Backspace `FRONTEND_CANCEL` and `KB_PHONE_CANCEL`.
Those stay unzeroed: the arrows' controls and the phone's own accept/cancel always, the frontend
accept/cancel only while the phone is out. "The phone is out" is the game's own flag that
`CREATE_MOBILE_PHONE` / `DESTROY_MOBILE_PHONE` set (1.0.8.0: `0x1792CB5`, its address read from the
native's code, which is checked first), or `SCRIPT_IS_USING_MOBILE_PHONE`'s (the next byte); the
log says `phone: out` / `phone: away`. While it is out the puppet move keeps Niko's tasks (his
phone task), which every other puppet frame clears, SkyState carries `kSkyPhoneOut` and Minecraft
draws no first-person hands or held items (the phone shows where its right hand is: the pickaxe
looked like the phone), nor held items on its third-person body.

Raw input allows one mouse registration per process, and Wine's DirectInput registers it for its
own window (`RIDEV_CAPTUREMOUSE | RIDEV_NOLEGACY`) whenever GTA acquires its mouse and removes it
when GTA lets go: alt-tab does both. Afterwards no `WM_INPUT` (no mouse look) and, with
`NOLEGACY`, no mouse button messages reached the game window until puppet mode restarted (a trip
through GTA's pause menu did that: the "Esc twice" workaround). While puppeting and focused,
`Input::Tick` checks the registration every 0.1 s (every frame for 3 s after a focus change) and
takes it back (`raw mouse: the registration was taken over ...`, `retaken` in the stats).

## Log

`<gamedir>/LibertyCraft.log` (truncated each start, flushed per line, also `OutputDebugStringA`).
Lines look like `[HH:MM:SS.mmm] [module] text`. A healthy run shows, in order:

    [main] LibertyCraft 0.1.0 (...) loading; log ...
    [main] GTAIV.exe version 1.0.8.0: supported
    [config] config: Puppet=1 CameraMode=final ...
    [main] game version 1.0.8.0 detected (base 0x...); hooks placed: ...
    [link] link created (#1): file Z:\dev\shm\libertycraft-bridge, 200327168 bytes (191 MiB), ...
    [input] game window 0x... subclassed (focused 1); menu key dik 0x18
    [game] first SkyState written: flags 0x1, MC pos ..., viewport 1920x1080, hour ...
    [game] teleport #N: Minecraft to MC x y z (GTA ...), yaw ...
    [game] camera rows check: the game's on-foot camera agrees with the pinned rows (...)
    [game] root->feet measured: 1.0xx m ...
    [game] Minecraft connected: pid ..., heartbeat N ms old, ...
    [collision] kColClear epoch 1 sent
    [game] Minecraft acknowledged teleport #N (now at MC ...)
    [input] raw mouse registered for the game window (...)
    [game] puppet ON: Minecraft drives the player (...)
    [game] stats 10s: frames 60.0/s, SkyState writes 60.0/s (teleport #N, acked #N), ...
    [game] stats 10s: input keys ... raw-mouse ... pad-zeroed ...
    [game] stats 10s: collision regions ... (tris ..., blocks ...), columns probed ...
    [game] stats 10s: motion ... frames, ... MC ticks, ... late frames, render delay ... ms
    [render] render: CRenderPhase::sm_pCurrent @..., grcViewport::sm_pCurrent @..., FusionFix loaded (logarithmic depth)
    [render] first draw command executed: render thread ... (game thread ...)
    [render] block renderer ready (vs_3_0/ps_3_0, managed buffers)
    [render] blocks use the final cam camera (RenderCamera=auto)
    [render] received Minecraft's block atlas 2048x2576 (5 mip levels, ... ms)
    [overlay] overlay texture 1920x1080
    [render] render ring ... KiB in 10.0s: section ... atlasRegion ...; overlay frames ... (uploaded ...)
    [render] render: ... frames drawn ..., N sections (... MiB, atlas yes ...); per frame: drawn ... sections, ... draw ... ms
    [blocks] Minecraft's solid blocks arrived (N sections so far): peds and vehicles collide with them
    [blocks] stats 10s: N solid sections (...); peds pushed out N times (...), vehicles touching blocks N frames, slowed N ...
    [combat] stats 10s: vehicles N per table write; vehicle hits N (...), occupants hit N, windows N, set on fire or blown up N

A trip to the blocky city and back:

    [city] blocky city: Minecraft's player went through a portal (kMcBlockyCity): hiding GTA's map geometry (building pool N slots, object pool N)
    [city] blocky city: GTA's map hidden: N buildings and N map objects in the pools, N hidden so far (+N this frame), scan ... ms
    [city] blocky city: GTA's map shown again (N of N hidden entities still there)
    [city] blocky city: Minecraft's player is back in the mirror world (N scans, ... ms average, ... ms worst)

`ERROR` / `WARNING` mark problems; an unsupported exe is a banner of `ERROR` lines.
