// LibertyCraft shared-memory protocol (GTA IV ASI plugin <-> Minecraft Fabric mod).
//
// Forked from SkyCraft (MIT, https://github.com/chasmlol/SkyCraft) protocol version 11. The byte
// layout is deliberately IDENTICAL to SkyCraft's so the Fabric mod, the host plugin and the
// Python test stand-ins stay interchangeable. Only the magic, the namespace and the mapping
// location differ.
//
// Transport: a 191 MiB plain file that both processes mmap. The Minecraft side (native Linux
// Java) creates it with FileChannel.map(READ_WRITE); the GTA IV side (32-bit Windows DLL under
// Wine/Proton) opens the same file through the Z: drive with CreateFileMapping(PAGE_READWRITE),
// which Wine implements as mmap(MAP_SHARED) on the same inode, so the pages are shared.
// On a native Windows setup both sides may instead use the named section kMappingName.
//
// Clocks: *HeartbeatMs fields are milliseconds of a monotonic clock since boot (Wine's
// GetTickCount64 == CLOCK_MONOTONIC_RAW / 1e6 on Linux). McState::tickQpc is in 100 ns units of
// the same clock (Wine's QueryPerformanceCounter == CLOCK_MONOTONIC_RAW / 100). The Java side
// reads CLOCK_MONOTONIC_RAW through the FFM API so the stamps are directly comparable.
//
// Coordinates: GTA IV (x east, y north, z up, metres) <-> Minecraft (x east, y up, z south):
// mc = (x, z, -y), gta = (x, -z, y), 1 block = 1 metre (SkyCraft used 70 Skyrim units).
//
// This header is the single source of truth for the byte layout. The Java side mirrors it in
// fabric/src/main/java/dev/libertycraft/link/Proto.java; if you change anything here, change it
// there too and bump kVersion.
//
// Handshake: whichever side starts first creates the bridge and sizes it to kMappingBytes; neither
// side ever shrinks or truncates it (pages a peer has mapped would vanish under it: SIGBUS). The
// host writes the header (magic, version, its pid, heartbeat) and zeroes its regions on every
// (re)start, including mcPid: Minecraft treats a cleared mcPid as "new host instance" because a fresh
// wineserver may hand GTA IV the same pid again. Minecraft then rewrites mcPid and resends its caches.
// Under Wine the host's pid is a Wine pid, so Minecraft judges host liveness by the heartbeat
// (8 s timeout); the host should keep it ticking during loading screens and while paused.
//
// All multi-byte values are little-endian.
// Coordinates in this protocol are always Minecraft space (blocks, Y up, Z south) unless noted.
#pragma once

#include <cstdint>

namespace libertycraft::proto
{
	inline constexpr std::uint32_t kMagic = 0x5954424C;  // "LBTY"
	inline constexpr std::uint32_t kVersion = 11;
	inline constexpr wchar_t       kMappingName[] = L"Local\\LibertyCraft_v1";  // native Windows only
	inline constexpr char          kBridgeFilePosix[] = "/dev/shm/libertycraft-bridge";  // Linux side
	inline constexpr wchar_t       kBridgeFileWine[] = L"Z:\\dev\\shm\\libertycraft-bridge";  // Wine side

	// 1 Minecraft block == 70 Skyrim units (Skyrim player ~128 units tall, MC player 1.8 blocks).
	inline constexpr double kUnitsPerBlock = 1.0;  // GTA IV metres per block (SkyCraft: 70 Skyrim units)

	// ---- region offsets ---------------------------------------------------------------------
	inline constexpr std::uint64_t kOffHeader = 0x0;
	inline constexpr std::uint64_t kOffSkyState = 0x100;
	inline constexpr std::uint64_t kOffMcState = 0x200;
	inline constexpr std::uint64_t kOffOverlayCtl = 0x300;
	inline constexpr std::uint64_t kOffOverlaySlotHdr = 0x340;  // 3 x 0x40
	inline constexpr std::uint64_t kOffWaterGrid = 0x400;       // host -> MC, see WaterGrid
	inline constexpr std::uint64_t kOffInputRing = 0x1000;
	inline constexpr std::uint64_t kOffCollisionRing = 0x20000;
	inline constexpr std::uint64_t kCollisionRingBytes = 32ull << 20;
	inline constexpr std::uint64_t kOffOverlayPixels = kOffCollisionRing + kCollisionRingBytes;
	inline constexpr std::uint32_t kMaxOverlayW = 3840;
	inline constexpr std::uint32_t kMaxOverlayH = 2160;
	inline constexpr std::uint64_t kOverlaySlotBytes = std::uint64_t(kMaxOverlayW) * kMaxOverlayH * 4;
	inline constexpr std::uint32_t kOverlaySlots = 3;
	inline constexpr std::uint64_t kOffActorTable = 0x12000;   // host -> MC, see ActorTable
	inline constexpr std::uint64_t kOffEventRing = 0x17000;    // MC -> host, see McEvent
	inline constexpr std::uint64_t kOffWorldEntities = 0x1C000;  // MC -> host, see WorldEntities
	inline constexpr std::uint64_t kOffRenderRing = kOffOverlayPixels + kOverlaySlotBytes * kOverlaySlots;
	inline constexpr std::uint64_t kRenderRingBytes = 64ull << 20;
	inline constexpr std::uint64_t kMappingBytes = kOffRenderRing + kRenderRingBytes;

	// ---- header @0x0 ------------------------------------------------------------------------
	struct Header
	{
		std::uint32_t magic;
		std::uint32_t version;
		std::uint32_t skyrimPid;
		std::uint32_t mcPid;
		std::uint64_t skyrimHeartbeatMs;  // GetTickCount64() at last Skyrim frame
		std::uint64_t mcHeartbeatMs;      // GetTickCount64() at last MC frame
	};
	static_assert(sizeof(Header) == 0x20);

	// ---- Skyrim -> MC state @0x100 (seqlock: seq odd while writing) -------------------------
	enum SkyFlags : std::uint32_t
	{
		kSkyInGame = 1u << 0,    // a save is loaded and the player exists
		kSkyMenuOpen = 1u << 1,  // a Skyrim menu owns input; MC should drop held keys
		kSkyLoading = 1u << 2,   // loading screen / cell transition in progress
		// LibertyCraft additions (bits only; the layout and kVersion stay SkyCraft's):
		// The host controls the player (Niko mode, a vehicle, a cutscene, a scripted scene). Minecraft
		// doesn't simulate its player meanwhile: no physics, no input, no damage; it follows
		// SkyState pos/yaw every tick and acknowledges teleports as they come. When the bit clears
		// the host bumps teleportSeq (the usual teleport handshake) and Minecraft resumes.
		kSkyHostDrives = 1u << 3,
		// Only together with kSkyHostDrives: the player sits in a vehicle. pos is where the riding
		// Minecraft player's feet go (the seat), yaw the vehicle's heading. Minecraft puts its player
		// on a mount (a boat by default) placed so its rider is at pos, every tick, and removes it
		// when the bit clears.
		kSkyInVehicle = 1u << 4,
		// LibertyCraft addition (a bit only): GTA IV shows a scene rather than gameplay (a cutscene, or a
		// mission script's own camera: a scripted cutscene, a minigame's view). Minecraft pauses meanwhile like
		// for kSkyMenuOpen (a singleplayer world, its mobs, their blasts and its sounds stand still) and its
		// HUD stays hidden; the host drops what Minecraft's mobs do to its world in the meantime.
		kSkyScene = 1u << 5,
		// LibertyCraft addition (a bit only): a phone call is going on in GTA IV (IS_MOBILE_PHONE_CALL_ONGOING).
		// Minecraft's sounds duck meanwhile, so the call can be heard.
		kSkyPhoneCall = 1u << 6,
	};
	// LibertyCraft addition (bits only; the layout and kVersion stay SkyCraft's): GTA IV's weather in
	// SkyState::flags bits 8 to 11, as its weather type + 1 (GtaWeather; 0: the host doesn't say).
	// Minecraft's own weather cycle stops while linked and follows it: raining for kGtaRain, kGtaDrizzle
	// and kGtaLightning, thundering for kGtaLightning.
	inline constexpr std::uint32_t kSkyWeatherShift = 8;
	inline constexpr std::uint32_t kSkyWeatherMask = 0xFu << kSkyWeatherShift;
	// LibertyCraft addition (a bit only): GTA IV's phone is out (a call, the phone book). GTA's phone
	// shows where Minecraft's first-person hand is: Minecraft draws no hands or held items meanwhile.
	inline constexpr std::uint32_t kSkyPhoneOut = 1u << 12;

	// GTA IV's weather types (FORCE_WEATHER_NOW, CWeather).
	enum GtaWeather : std::uint32_t
	{
		kGtaExtraSunny = 0,
		kGtaSunny = 1,
		kGtaSunnyWindy = 2,
		kGtaCloudy = 3,
		kGtaRain = 4,
		kGtaDrizzle = 5,
		kGtaFoggy = 6,
		kGtaLightning = 7,
	};

	// Skyrim's water (lakes, rivers, the sea) around the player, for Minecraft to treat as its own
	// water: swimming, floating, drowning. Seqlock like SkyState.
	inline constexpr std::uint32_t kWaterGridSize = 16;
	inline constexpr float         kNoWater = -1.0e30f;

	struct WaterGrid
	{
		std::uint32_t seq;
		std::int32_t  originX, originZ;  // Minecraft block column of surface[0]
		std::uint32_t worldId;           // as in SkyState
		float         surface[kWaterGridSize * kWaterGridSize];  // [z * size + x]: MC y of the water surface; kNoWater: none
	};
	static_assert(sizeof(WaterGrid) <= 0xC00);

	struct SkyState
	{
		std::uint32_t seq;
		std::uint32_t flags;           // SkyFlags
		std::uint32_t worldId;         // worldspace FormID (exterior) or cell FormID (interior); GTA IV: 0 outdoors, else the interior (same coordinates)
		std::uint32_t collisionEpoch;  // bumps on world change; MC drops all collision data (GTA IV: a game load or a reconnect, not an interior)
		double        posX, posY, posZ;  // Skyrim player feet, MC coords
		float         yaw, pitch;        // authoritative look (MC degrees)
		std::uint32_t teleportSeq;       // MC teleports its player to pos when this changes
		std::uint32_t viewportW, viewportH;
		float         gameHour;
	};
	static_assert(sizeof(SkyState) == 0x40);

	// ---- MC -> Skyrim state @0x200 (seqlock) ------------------------------------------------
	enum McFlags : std::uint32_t
	{
		kMcInWorld = 1u << 0,
		kMcScreenOpen = 1u << 1,  // an MC GUI screen (inventory, chat, ...) is open
		kMcOnGround = 1u << 2,
		kMcSneaking = 1u << 3,
		kMcSprinting = 1u << 4,
		kMcDead = 1u << 5,
		kMcSwimming = 1u << 6,
		kMcFlying = 1u << 7,
		// LibertyCraft addition (a bit only; the layout and kVersion stay SkyCraft's): the player holds
		// a shield up and it blocks (Minecraft's own isBlocking: after the shield's raise delay). It
		// blocks what comes from within 90 degrees of where the player looks (yaw): GTA IV keeps Niko
		// quiet for those hits (no pain voice, no reaction), which Minecraft blocks.
		kMcBlocking = 1u << 8,
		// LibertyCraft addition (a bit only; the layout and kVersion stay SkyCraft's): Minecraft's player is
		// in the blocky city (libertycraft:blocky_city, reached through a nether portal in the mirror world),
		// a block copy of Liberty City at the same coordinates (1:1) that Minecraft streams like any blocks.
		// Everything else goes on as usual (puppet mode, teleports, combat); the host hides its own map
		// geometry meanwhile (buildings, terrain, props, their LODs and shadows; not the sky, water, peds,
		// vehicles or the HUD), so the blocks are the city. The city's own blocks don't come in kRenSolids /
		// kRenLiquids (GTA IV's collision is the same city); blocks the player placed there do.
		kMcBlockyCity = 1u << 9,
		// LibertyCraft addition (a bit only; the layout and kVersion stay SkyCraft's): the Minecraft player is in
		// creative or spectator mode, so nothing hurts it. The host keeps GTA IV's peds from dragging it out of a
		// vehicle then (in survival and adventure GTA's own dragging stays).
		kMcCreative = 1u << 10,
	};

	struct McState
	{
		std::uint32_t seq;
		std::uint32_t flags;          // McFlags
		double        x, y, z;        // interpolated feet position (MC coords)
		float         yaw, pitch;     // MC rotation (degrees)
		float         eyeHeight;      // blocks above feet
		float         sensitivity;    // MC mouse sensitivity option (0..1)
		std::uint32_t teleportAck;    // last SkyState::teleportSeq applied
		std::uint32_t guiScale;
		std::uint64_t frameCounter;
		float         fovDeg;         // effective vertical FOV (includes sprint / fluid modifiers)
		float         bobPhase;       // MC walk-bob phase (interpolated walk distance); 0 if bobbing is off
		float         bobAmount;      // MC walk-bob amplitude
		std::uint32_t pad4C;          // LibertyCraft: the player's health (kMcVitalsValid)
		double        eyeX, eyeY, eyeZ;  // MC camera position (interpolated, includes sneak eye lerp)

		// Raw 20 Hz physics ticks, so Skyrim can interpolate on its own frame clock exactly like
		// Minecraft's renderer does with partial ticks (no judder from the two games' frame phase).
		std::int64_t tickQpc;             // QueryPerformanceCounter at the (remainder-corrected) tick
		double       prevX, prevY, prevZ;  // feet at the previous tick
		double       curX, curY, curZ;     // feet at the latest tick
		float        tickEyeO, tickEye;      // Camera's smoothed eye height, previous/latest tick
		float        walkDistO, walkDist;    // walk-bob phase inputs
		float        bobO, bob;              // walk-bob amplitude inputs
		float        tickMs;                 // milliseconds per tick (50 unless /tick rate changed)
		std::uint32_t tickPad;               // LibertyCraft: the player's armour (kMcVitalsValid)

		// Minecraft's camera (F5): 0 first person, 1 third person behind, 2 third person in front
		// (looking back at the player). cameraDistance is how far Minecraft's camera sits from
		// the eye, after its own zoom collision (Minecraft blocks and Skyrim's triangles).
		std::uint32_t cameraMode;
		float         cameraDistance;
	};
	static_assert(sizeof(McState) == 0xC8);

	// LibertyCraft addition (padding only; the layout and kVersion stay SkyCraft's): the Minecraft
	// player's vitals, for GTA IV's own HUD. pad4C = health * 100 (bits 0-15) | max health * 100
	// (bits 16-31), each rounded and clamped to 65535; tickPad = armour points (bits 0-7) | absorption,
	// rounded (bits 8-15) | kMcVitalsValid. A writer that doesn't know this leaves both 0: not valid.
	inline constexpr std::uint32_t kMcVitalsValid = 1u << 31;
	static_assert(sizeof(McState) <= 0x100);

	// ---- overlay triple buffer @0x300 --------------------------------------------------------
	// state: bits 0-1 = index of the "middle" slot, bit 2 = middle holds an unread frame.
	// Writer (MC) renders into its private back slot, then xchg(state, back | kDirty) and keeps
	// the returned index as its new back slot. Reader (Skyrim) does xchg(state, front) only when
	// the dirty bit is set and keeps the returned index as its new front slot.
	inline constexpr std::uint32_t kOverlayDirty = 1u << 2;

	struct OverlayCtl
	{
		std::uint32_t state;
		std::uint32_t pad;
		std::uint64_t framesPublished;
	};

	struct OverlaySlotHdr
	{
		std::uint32_t width;
		std::uint32_t height;
		std::uint32_t flags;  // bit0: rows are bottom-up
		std::uint32_t pad;
		std::uint64_t frameId;
		std::uint8_t  reserved[0x40 - 0x18];
	};
	static_assert(sizeof(OverlaySlotHdr) == 0x40);

	// LibertyCraft addition (a flag bit and the reserved bytes; the layout and kVersion stay SkyCraft's):
	// dirty tiles. A slot always holds a whole frame, but with flags bit kOverlayFlagTiles the frame differs
	// from the frame published as baseFrameId only in the tiles set in tiles[]: the frame is cut into a
	// kOverlayTileGrid x kOverlayTileGrid grid of tiles ceil(width / 16) x ceil(height / 16) pixels (the
	// last ones cut short), tile (tx, ty) of slot memory order (rows as stored, before any bottom-up flip)
	// is bit (ty * 16 + tx) % 32 of tiles[(ty * 16 + tx) / 32]. A reader whose copy holds frame
	// baseFrameId (and the same size) only needs those tiles; any other reader copies it all. Writers
	// may also skip frames that are unchanged. Without the bit the frame says nothing about earlier ones.
	inline constexpr std::uint32_t kOverlayFlagTiles = 1u << 1;
	inline constexpr std::uint32_t kOverlayTileGrid = 16;
	inline constexpr std::uint32_t kOverlayHdrBaseFrameOff = 0x18;  // u64 baseFrameId, in reserved[]
	inline constexpr std::uint32_t kOverlayHdrTilesOff = 0x20;      // u32 tiles[8], in reserved[]

	// ---- input ring @0x1000 (Skyrim produces, MC consumes) ----------------------------------
	inline constexpr std::uint32_t kInputRingEntries = 4096;  // power of two
	inline constexpr std::uint64_t kInputRingHeadOff = 0x00;  // u64, written by Skyrim
	inline constexpr std::uint64_t kInputRingTailOff = 0x40;  // u64, written by MC
	inline constexpr std::uint64_t kInputRingDataOff = 0x80;

	enum InputType : std::uint16_t
	{
		kInKey = 1,          // code = SDL scancode, a = 1 press / 0 release
		kInMouseButton = 2,  // code = SDL button (1 L, 2 M, 3 R, 4 X1, 5 X2), a = 1 press / 0 release
		kInScroll = 3,       // a = wheel notches * 120 (positive = up)
		kInCursor = 4,       // a, b = absolute cursor position in overlay pixels
		kInText = 5,         // a = unicode code point
		kInReleaseAll = 6,   // release every held key/button (input focus left MC)
		kInHurt = 7,         // Skyrim hit the player: code = HurtKind, a = Skyrim damage * 100, b = attacker FormID, c = HurtFlags
		kInOpenMenu = 8,     // open Minecraft's pause/options menu
		// LibertyCraft addition (a new type only; the layout and kVersion stay): one of GTA IV's bullets
		// stopped at a Minecraft block. code = the face it hit (0 down, 1 up, 2 north, 3 south, 4 west,
		// 5 east: Minecraft's Direction order), a, b, c = where, Minecraft coordinates * 256. Minecraft
		// shows the block's hit particles there.
		kInBulletImpact = 9,
		// LibertyCraft addition (a new type only): GTA IV brought the player back after dying (wasted, at
		// a hospital). No fields. Minecraft sets the player's health and food to full.
		kInRestore = 10,
		// LibertyCraft addition (a new type only): one of GTA IV's bullets hit a Minecraft mob (one Minecraft
		// sent as kEvMob). code = GTA IV's weapon type, a = the mob's entity id, b = the ActorTable formId
		// of the ped that fired (0: not known, kMobHitByPlayer: the player), c = the Minecraft damage * 100
		// (GTA IV's damage for the weapon / kMobDamageScale). Minecraft hurts the mob as from that ped.
		kInMobHit = 11,
	};
	inline constexpr std::int32_t kMobHitByPlayer = -1;
	inline constexpr float        kMobDamageScale = 5.0f;  // GTA IV damage / this = Minecraft damage (a pistol's 25: 5)

	enum HurtKind : std::uint16_t
	{
		kHurtMelee = 0,
		kHurtProjectile = 1,
		kHurtMagic = 2,
		kHurtOther = 3,
	};

	enum HurtFlags : std::uint32_t
	{
		kHurtBlockedInSkyrim = 1u << 0,
		kHurtPowerAttack = 1u << 1,
		// LibertyCraft addition: bits 16 to 24 hold the MC yaw (whole degrees, 0 to 359) of the direction
		// from the player toward what hurt it (an attacker, a car, a blast), so Minecraft can place the
		// damage source there: a shield blocks what comes from in front.
		kHurtHasDirection = 1u << 2,
	};
	inline constexpr std::uint32_t kHurtDirectionShift = 16;

	// ---- actor table @0x12000 (Skyrim -> MC, seqlock) ----------------------------------------
	// Nearby Skyrim actors, mirrored in Minecraft as invisible hittable proxy entities.
	inline constexpr std::uint32_t kMaxActors = 256;

	enum ActorFlags : std::uint32_t
	{
		kActorHostile = 1u << 0,    // hostile to the player right now
		kActorDead = 1u << 1,
		kActorEssential = 1u << 2,
		kActorInCombat = 1u << 3,
		// LibertyCraft addition (a bit only; the layout and kVersion stay SkyCraft's): the record is one
		// piece of a GTA IV vehicle, not a ped. A vehicle is long and turned any way, and an
		// ActorRecord is an upright box square to the world axes, so a vehicle goes out as up to
		// kActorVehicleSegments such boxes: a row along its axis as wide as its body, small enough that
		// none sticks out of the body (seen from above) by more than a few centimetres whichever way it
		// faces, each as tall as the body's lowest top along it (bonnet, boot), then a narrower row
		// within the greenhouse as tall as the cabin: width = the box's side, height = its height,
		// (x, y, z) = the box's bottom centre.
		// Their formId is kActorVehicleTag | (vehicle script handle << 4) | piece (0 at the front).
		// Minecraft makes them hittable and solid like the ped records; a kEvHitActor on any piece hits
		// the vehicle (where it landed: kEvHitPoint). Peds sitting in a vehicle get no record of their own.
		kActorVehicle = 1u << 4,
		// LibertyCraft addition (a bit only): with kActorVehicle, a piece of the vehicle the player sits in
		// (drives, rides in, or is getting into). Minecraft makes no stand-in of it (the player's own mount
		// sits inside it), only uses it to run Minecraft's mobs over and push them aside; whatever it runs
		// over is the player's doing. A host that doesn't set it leaves the player's vehicle out.
		kActorPlayerVehicle = 1u << 5,
		// LibertyCraft addition (a bit only): with kActorVehicle, someone sits in the vehicle (a driver or
		// passengers, the player too). Minecraft's hostile mobs go for such vehicles as for peds on foot
		// (they bang on it, shoot it, blow up beside it); empty ones they leave alone.
		kActorOccupied = 1u << 6,
		// LibertyCraft addition (a bit only): a mission character (a ped a GTA IV mission script owns:
		// IS_PED_A_MISSION_PED), or a piece of a vehicle one sits in (or of a mission's own vehicle someone
		// sits in). Minecraft's mobs leave it alone: they don't hunt it, and the host lets no mob's hit or
		// blast reach it (the player's own hits still count).
		kActorMission = 1u << 7,
	};

	inline constexpr std::uint32_t kActorVehicleTag = 0x56000000u;  // 'V'
	inline constexpr std::uint32_t kActorVehicleSegments = 16;     // at most, per vehicle

	struct ActorRecord
	{
		std::uint32_t formId;
		std::uint32_t flags;       // ActorFlags
		float         x, y, z;     // feet, MC coords
		float         yaw;         // MC degrees
		float         width;       // blocks
		float         height;      // blocks
		float         healthFrac;  // 0..1
		std::uint16_t level;
		std::uint16_t pad;
		char          name[24];    // display name, UTF-8, NUL-terminated (truncated)
	};
	static_assert(sizeof(ActorRecord) == 64);

	struct ActorTable
	{
		std::uint32_t seq;
		std::uint32_t count;
		// LibertyCraft addition (in SkyCraft's padding; the layout and kVersion stay): when the host wrote
		// this table, QueryPerformanceCounter in 100 ns units (the clock of McState::tickQpc), 0 if it
		// doesn't say. Minecraft takes the vehicles' speeds from how far their records moved between two
		// tables over the difference of their stamps.
		std::uint64_t stamp;
		std::uint8_t  pad[0x40 - 16];
		ActorRecord   actors[kMaxActors];
	};
	static_assert(sizeof(ActorTable) == 0x40 + 64 * kMaxActors);

	// ---- event ring @0x17000 (MC -> Skyrim) ---------------------------------------------------
	inline constexpr std::uint32_t kEventRingEntries = 512;  // power of two
	inline constexpr std::uint64_t kEventRingHeadOff = 0x00;  // u64, written by MC
	inline constexpr std::uint64_t kEventRingTailOff = 0x40;  // u64, written by Skyrim
	inline constexpr std::uint64_t kEventRingDataOff = 0x80;

	enum McEventType : std::uint32_t
	{
		kEvHitActor = 1,    // formId, a = MC damage (after MC's own modifiers), b/c = knockback dir x/z (MC), d = knockback strength
		kEvPlayerDied = 2,  // the Minecraft player died: kill the Skyrim player
		kEvExplosion = 3,   // a Minecraft explosion (TNT, creeper, ...): a/b/c = centre (MC coords), d = radius (blocks);
		                    // LibertyCraft: flags = ExplosionFlags (a firework rocket's burst also sets formId and weapon)
		kEvArrowStuck = 4,  // an arrow stuck in a Skyrim actor: formId, a/b/c = where it hit (MC coords), d = flight yaw,
		                    // flags = flight pitch (float bits), weapon = arrow texture (0 plain, 1 tipped, 2 spectral)
		kEvSkillUse = 5,    // the player used a Skyrim skill in Minecraft: formId = Skyrim skill (ActorValue: 9 Block,
		                    // 10 Smithing, 11 Heavy Armor, 12 Light Armor), a = uses (as Skyrim's AdvanceSkill counts them)
		// LibertyCraft addition (a new type; the layout and kVersion stay SkyCraft's): where the next
		// kEvHitActor with the same formId landed, sent right before it. a/b/c = a point on the line
		// the blow or projectile came along, at the stand-in (MC coords); d = that line's yaw and
		// flags = its pitch (float bits), MC degrees, pointing the way it travelled. The host follows
		// the line into the real vehicle to find what it struck (body or which window). Sent for
		// vehicle pieces (kActorVehicle) only; a host that doesn't know it ignores it.
		kEvHitPoint = 6,
		// LibertyCraft addition (a new type; the layout and kVersion stay): the Minecraft player ran into
		// a ped's stand-in (alive or dead; peds aren't solid for the player): formId, a = the player's
		// speed (m/s, its motion this tick), b/c = the horizontal direction of that motion (MC x/z,
		// unit; 0 when standing), d = how far the player is into the stand-in (blocks, horizontally).
		// flags = BumpFlags. Sent every tick of contact; the host pushes the ped out of the way, makes
		// it stumble or knocks it down by the speed (and its own cooldowns).
		kEvBump = 7,
		// LibertyCraft addition (a new type; the layout and kVersion stay): a hostile Minecraft mob near the
		// player, sent every 5 ticks for each one within kMobRange of the player (at most kMaxMobs, nearest
		// first, and only while the ring is at most half full). flags = its entity id (Minecraft's),
		// formId = the ActorTable formId of the ped it is after (0: none, or the player), a/b/c = its feet
		// (MC coords), d = its height (blocks), weapon = its width in hundredths of a block (bits 0 to 15)
		// | MobFlags. The host makes GTA IV's peds deal with it (armed ones and police nearby shoot at it,
		// the rest run) and lets GTA IV's bullets hit it (kInMobHit). Not sent again for kMobGoneSeconds:
		// gone (dead, unloaded, out of range).
		kEvMob = 8,
		// LibertyCraft addition (a new type; the layout and kVersion stay): Minecraft's time of day was set
		// (/time set or add, a night slept through in a bed): a = GTA IV's hour for it, 0 to 24 with the
		// minutes as its fraction (Minecraft tick t: (t / 1000 + 6) mod 24). The host sets its clock there
		// (SET_TIME_OF_DAY); Minecraft's clock then follows GTA IV's again (SkyState::gameHour).
		kEvSetTime = 9,
		// LibertyCraft addition (a new type; the layout and kVersion stay): Minecraft's weather was set
		// (/weather clear, rain or thunder): formId = the GtaWeather for it (clear kGtaExtraSunny, rain
		// kGtaRain, thunder kGtaLightning), a = for how long (seconds; 0: until told otherwise). The host
		// forces it (FORCE_WEATHER_NOW) and gives GTA IV its own weather back when the time is up
		// (RELEASE_WEATHER); Minecraft follows GTA IV's weather (kSkyWeatherShift).
		kEvSetWeather = 10,
	};

	enum MobFlags : std::uint32_t
	{
		kMobAfterPlayer = 1u << 16,  // it is after the player
	};
	inline constexpr float         kMobRange = 80.0f;  // blocks from the player
	inline constexpr std::uint32_t kMaxMobs = 32;
	inline constexpr float         kMobGoneSeconds = 0.75f;

	// LibertyCraft addition (bits and conventions only; the layout and kVersion stay SkyCraft's): what a
	// kEvExplosion is. SkyCraft sends 0 (any ServerExplosion: TNT, creepers, beds, crystals).
	// kExplosionFirework: a firework rocket with stars burst (FireworkRocketEntity's explode, a crossbow
	// shot, a hand launch or an elytra boost; no stars: no burst and no event). a/b/c = where it burst
	// (where it struck something when it did, else where it was), d = the blast radius (blocks) the
	// stars give, formId = the stand-in it struck (an ActorTable formId; 0: it burst in the air or on a
	// surface), weapon = how many stars it carried.
	enum ExplosionFlags : std::uint32_t
	{
		kExplosionFirework = 1u << 0,
		kExplosionByPlayer = 1u << 1,  // the player launched it (the rocket's owner is the player)
		// LibertyCraft addition: a Minecraft mob caused it (a creeper, a ghast's fireball), not the player:
		// GTA IV's blast still happens, but it is no crime of the player's.
		kExplosionByMob = 1u << 2,
	};

	enum BumpFlags : std::uint32_t
	{
		kBumpSprinting = 1u << 0,
		kBumpFlying = 1u << 1,   // elytra
		kBumpNewContact = 1u << 2,  // the first tick of this contact
	};

	enum HitFlags : std::uint32_t
	{
		kHitCritical = 1u << 0,
		kHitProjectile = 1u << 1,
		kHitSweep = 1u << 2,
		kHitFire = 1u << 3,
		// LibertyCraft addition: the hit came from an explosion (Minecraft's blast hurt the stand-in;
		// the host's own blast from kEvExplosion already hits the real thing).
		kHitExplosion = 1u << 4,
		// LibertyCraft addition: Minecraft mobs dealt all of this hit (a zombie's blow, a skeleton's arrow,
		// a creeper's blast), the player none of it. The host hurts the ped as usual, but it is no crime of
		// the player's and the ped doesn't turn on the player.
		kHitByMob = 1u << 5,
	};

	// What landed a kEvHitActor (Skyrim plays that weapon class's impact effect and sounds).
	enum HitWeapon : std::uint32_t
	{
		kWeaponUnarmed = 0,
		kWeaponBlade = 1,   // swords
		kWeaponAxe = 2,
		kWeaponBlunt = 3,   // maces, pickaxes, shovels, hoes, anything else held
		kWeaponPierce = 4,  // tridents, spears
		kWeaponArrow = 5,   // arrows and other projectiles
	};

	struct McEvent
	{
		std::uint32_t type;
		std::uint32_t formId;
		float         a, b, c, d;
		std::uint32_t flags;
		std::uint32_t weapon;  // HitWeapon for kEvHitActor
	};
	static_assert(sizeof(McEvent) == 32);

	// ---- world entities @0x1C000 (MC -> Skyrim, seqlock) -------------------------------------
	// Minecraft things Skyrim draws itself each frame (arrows, dropped items, block cracks) + the
	// block outline.
	inline constexpr std::uint32_t kMaxWorldEntities = 160;

	enum WorldEntityKind : std::uint32_t
	{
		kWeArrow = 1,    // uv[0]: the arrow's item icon
		kWeItem = 2,     // dropped/thrown item: a flat sprite (uv[0]) turning about the vertical
		kWeTrident = 3,  // uv[0]: the trident's item icon
		kWeBlock = 4,    // dropped block item: a spinning cube of side `scale`, uv[0..2] = side, top, bottom
		kWeCrack = 5,    // block-breaking cracks over the box at (x, y, z) of size ext, uv[0] = crack stage
		kWeShadow = 6,   // a player's or mob's feet at (x, y, z), `scale` wide: its soft contact shadow
	};

	struct WorldEntity
	{
		std::uint32_t kind;        // WorldEntityKind
		std::uint32_t id;          // MC entity id (stable while it exists)
		float         x, y, z;     // MC coords (interpolated at MC's render time)
		float         yaw, pitch;  // MC degrees
		float         scale;
		float         ext[3];      // kWeCrack: box size
		float         uv[3][4];    // atlas rects {u0, v0, u1, v1}
		std::uint32_t tint;        // RGBA8 multiplier for the top face (grass, leaves); 0 = none
	};
	static_assert(sizeof(WorldEntity) == 96);

	struct WorldEntities
	{
		std::uint32_t seq;
		std::uint32_t count;
		std::uint32_t hasSelection;           // draw an outline around the targeted block
		float         selMin[3], selMax[3];   // MC coords
		std::uint8_t  pad[0x40 - 36];
		WorldEntity   entities[kMaxWorldEntities];
	};
	static_assert(sizeof(WorldEntities) == 0x40 + sizeof(WorldEntity) * kMaxWorldEntities);
	static_assert(kOffWorldEntities + sizeof(WorldEntities) <= kOffCollisionRing);

	// ---- render ring (MC -> Skyrim) -----------------------------------------------------------
	// Byte ring like the collision ring. Minecraft ships its own block meshes (built by Minecraft's
	// block renderer: models, tint, AO, lighting) and its block atlas; Skyrim draws them in its own
	// frame so blocks stay locked to the world and are occluded by Skyrim geometry.
	inline constexpr std::uint64_t kRenRingHeadOff = 0x00;
	inline constexpr std::uint64_t kRenRingTailOff = 0x40;
	inline constexpr std::uint64_t kRenRingDataOff = 0x80;
	inline constexpr std::uint64_t kRenRingDataBytes = kRenderRingBytes - kRenRingDataOff;

	enum RenType : std::uint32_t
	{
		kRenPad = 0,
		kRenAtlas = 1,     // RenAtlas + RGBA8 pixels (w * h * 4), top row first
		kRenSection = 2,   // RenSection + RenVertex[vertexCount] (triangle list); 0 vertices = remove
		kRenClearAll = 3,  // drop every section (world change)
		kRenTexture = 4,   // RenTexture + RGBA8 pixels: an entity texture (player skin, armour, ...)
		kRenAvatar = 5,    // RenAvatar + RenBatch[batchCount] + RenVertex[vertexCount]: the player's
		                   // model this frame; 0 batches = not shown (first person)
		kRenScene = 6,     // RenScene + RenBatch[batchCount] + RenVertex[vertexCount]: every other
		                   // entity and all particles this frame, relative to RenScene's origin
		kRenAtlasRegion = 7,  // RenAtlasRegion + RGBA8 pixels: an animated sprite's current frame
		kRenLights = 8,       // RenLights + RenLight[count]: a section's light-emitting blocks (sent
		                      // after its kRenSection; 0 = none)
		kRenSolids = 10,      // RenSolids + 512-byte bitset (bit x + 16z + 256y): which blocks of a
		                      // section NPCs collide with (sent after its kRenSection; 0 = none)
		kRenDug = 11,         // RenDug + 512-byte bitset (bit x + 16z + 256y): which blocks of a section
		                      // were dug out of Skyrim's world (its geometry there is gone); 0 = none
		kRenLiquids = 12,     // LibertyCraft addition (a new type; the layout and kVersion stay SkyCraft's;
		                      // a host that doesn't know it ignores it): RenLiquids + RenLiquid[count], a
		                      // section's water and lava blocks (sent after its kRenSection; 0 = none)
		kRenRagdoll = 9,      // RenAvatar + RenBatch[] + RenVertex[]: the player's body standing still,
		                      // relative to the feet and facing +Z, split into its parts (RenBatch
		                      // flags bits 8-11: RagdollPart; bit 12 kRagdollHeld: a held item, on its
		                      // arm). Sent about once a second while alive and at once when the skin,
		                      // armour or held items change. Skyrim hangs the parts on its ragdoll when
		                      // the player dies; GTA IV poses them on Niko's skeleton while it animates him.
	};

	struct RenSolids
	{
		std::int32_t  sx, sy, sz;  // section coords, as in RenSection
		std::uint32_t count;       // solid blocks (0: none, and no bitset follows)
	};

	struct RenDug
	{
		std::int32_t  sx, sy, sz;  // section coords, as in RenSection
		std::uint32_t count;       // dug blocks (0: none, and no bitset follows)
		std::uint32_t worldId;     // the Skyrim world (SkyState::worldId) the bits belong to
		std::uint32_t pad;
	};
	static_assert(sizeof(RenDug) == 24);

	// What a piece of diggable Skyrim geometry is made of, as the Minecraft block it digs into
	// (ColTri flags bits 8-15). Chosen on the Skyrim side from Havok materials and object types.
	enum DigMaterial : std::uint8_t
	{
		kDigNone = 0,  // not known: stone
		kDigGrass = 1,
		kDigDirt = 2,
		kDigStone = 3,
		kDigCobble = 4,
		kDigSnow = 5,
		kDigIce = 6,
		kDigSand = 7,
		kDigGravel = 8,
		kDigMud = 9,
		kDigOakLog = 10,
		kDigSpruceLog = 11,
		kDigBirchLog = 12,
		kDigPlanks = 13,
		kDigMetal = 14,
		kDigGlass = 15,
		kDigOrganic = 16,
		kDigCloth = 17,
		kDigBone = 18,
		kDigWeb = 19,
		kDigAsh = 20,
		kDigBedrock = 21,  // Minecraft only: a few blocks under the land
		kDigMaterialCount
	};

	enum RagdollPart : std::uint32_t
	{
		kPartNone = 0,
		kPartHead = 1,
		kPartBody = 2,
		kPartRightArm = 3,
		kPartLeftArm = 4,
		kPartRightLeg = 5,
		kPartLeftLeg = 6,
		kPartCount = 7,
	};
	// kRenRagdoll RenBatch flags: the part (bits 8-11) and whether the batch is a held item (Minecraft
	// drops it when the player dies; it rides its arm while alive).
	inline constexpr std::uint32_t kRagdollPartShift = 8;
	inline constexpr std::uint32_t kRagdollHeld = 1u << 12;
	// LibertyCraft addition (a flag bit only): a cape or an elytra (on the body part). It hangs down the
	// back past the hips, so a host posing the body seated hides it (it came out under a car's floor).
	inline constexpr std::uint32_t kRagdollBack = 1u << 13;

	struct RenLights
	{
		std::int32_t  sx, sy, sz;  // section coords, as in RenSection
		std::uint32_t count;
	};

	enum LightKind : std::uint8_t
	{
		kLightSteady = 0,
		kLightFlame = 1,  // torches, fire, campfires, candles: flicker
		kLightLava = 2,   // lava, magma: a slow glow
	};

	enum BlockHazard : std::uint8_t
	{
		kHazardNone = 0,
		kHazardFire = 1,   // fire, soul fire, campfires: burns what stands in it
		kHazardLava = 2,   // lava: burns hard
		kHazardMagma = 3,  // magma block: hurts what stands on top of it
	};

	// kRenLiquids: water and lava (vehicles struggle in them; lava also burns, see RenLight).
	struct RenLiquids
	{
		std::int32_t  sx, sy, sz;  // section coords, as in RenSection
		std::uint32_t count;       // liquid blocks (0: none)
	};

	enum LiquidKind : std::uint8_t
	{
		kLiquidNone = 0,
		kLiquidWater = 1,
		kLiquidLava = 2,
	};

	struct RenLiquid
	{
		std::uint8_t x, y, z;  // block within the section
		std::uint8_t info;     // bits 0-3: the liquid's surface in the block, in fifteenths of a block (15: full,
		                       // e.g. under more of it; a lone source is 13); bits 4-5: LiquidKind
	};
	static_assert(sizeof(RenLiquid) == 4);

	struct RenLight
	{
		std::uint8_t  x, y, z;  // block within the section
		std::uint8_t  level;    // Minecraft light emission, 1-15
		std::uint32_t color;    // RGB8 (r low byte); top byte: LightKind in bits 0-3, BlockHazard in 4-7
	};
	static_assert(sizeof(RenLight) == 8);

	struct RenAtlasRegion
	{
		std::uint32_t x, y, width, height;  // pixels in the combined atlas (kRenAtlas)
	};

	struct RenScene
	{
		double        originX, originY, originZ;  // MC block the positions are relative to
		std::uint32_t batchCount;
		std::uint32_t vertexCount;
	};

	struct RenTexture
	{
		std::uint32_t id;  // 1+, referenced by RenBatch::texture
		std::uint32_t width, height;
		std::uint32_t pad;
	};

	// The player as Minecraft's own entity renderer draws it (skin, armour, held items, cape),
	// posed and animated, with positions in blocks relative to the player's feet: Skyrim puts
	// it at its own interpolated feet position, the one its camera follows.
	struct RenAvatar
	{
		std::uint32_t batchCount;
		std::uint32_t vertexCount;
	};

	struct RenBatch
	{
		std::uint32_t texture;  // 0: the block/item atlas, else a RenTexture id
		std::uint32_t first;    // first vertex
		std::uint32_t count;    // vertices (multiple of 3)
		std::uint32_t flags;    // bit0: translucent (blended, after the solid pass; casts no shadow)
	};

	struct RenAtlas
	{
		std::uint32_t width, height;
	};

	struct RenSection
	{
		std::int32_t  sx, sy, sz;   // section coords (16-block cubes)
		std::uint32_t vertexCount;  // multiple of 3
	};

	struct RenVertex
	{
		float         x, y, z;  // MC coords relative to the section origin (sx*16, sy*16, sz*16)
		float         u, v;     // atlas UV
		std::uint32_t color;    // RGBA8 (tint * ambient occlusion; Minecraft's fixed face shading is left out)
		std::uint32_t light;    // low byte: block light 0-15, next byte: sky light 0-15
		std::uint32_t flags;    // bit0: cutout (alpha test), bit1: translucent,
		                        // bits 4-6: face normal as MC Direction ordinal + 1 (0 = none: lit without a normal)
	};
	static_assert(sizeof(RenVertex) == 32);

	struct InputEvent
	{
		std::uint16_t type;
		std::uint16_t code;
		std::int32_t  a;
		std::int32_t  b;
		std::int32_t  c;
	};
	static_assert(sizeof(InputEvent) == 16);

	// ---- collision ring @0x20000 (Skyrim produces, MC consumes) -----------------------------
	// Byte ring. Every message starts 8-byte aligned with {u32 type, u32 payloadBytes}.
	// A kColPad message means "skip to the start of the ring".
	inline constexpr std::uint64_t kColRingHeadOff = 0x00;  // u64 total bytes written
	inline constexpr std::uint64_t kColRingTailOff = 0x40;  // u64 total bytes consumed
	inline constexpr std::uint64_t kColRingDataOff = 0x80;
	inline constexpr std::uint64_t kColRingDataBytes = kCollisionRingBytes - kColRingDataOff;

	enum ColType : std::uint32_t
	{
		kColPad = 0,
		kColClear = 1,   // payload: u32 epoch
		kColRegion = 2,  // payload: ColRegion + ColBlock[count]
		kColTris = 3,    // payload: ColRegion (count = triangles) + ColTri[count]; sent before kColRegion
		// LibertyCraft addition (a message type only; the layout and kVersion stay SkyCraft's): payload
		// ColRegion (count 0, minY/maxY 0) naming one column of regions, [minX, maxX] x [minZ, maxZ] at every
		// height. GTA IV no longer tracks it (the player went far away) and probes and sends it again before
		// the player gets near, so Minecraft may drop what it holds there whenever it likes. Without these
		// messages Minecraft keeps every region it was ever sent until the next kColClear.
		kColForget = 4,
	};

	// Exact Skyrim collision triangle (MC space) for the player's smooth collider.
	enum ColTriFlags : std::uint32_t
	{
		kTriStairHelper = 1u << 0,  // Skyrim's invisible stair ramp: walkable, never a wall
		kTriDiggable = 1u << 1,     // ground, rock, trees...: can be dug into (bits 8-15: DigMaterial).
		                            // Its normal faces out of the solid side (winding is outward).
		kTriGhost = 1u << 2,        // a diggable triangle as it was before blocks were dug out of it:
		                            // not collision, only for telling what's inside Skyrim's geometry
		kTriTerrain = 1u << 3,      // the land (a height field)
		// LibertyCraft addition (a bit only; the layout and kVersion stay SkyCraft's): bits 16-23 hold the
		// GTA IV material of the surface the triangle was probed on, as its index in GTA IV's
		// common/data/materials/materials.dat (0 DEFAULT, 3 CONCRETE, 8 TARMAC, 16 PAVING_SLABS, 37 GRASS,
		// ...), for the blocky city's blocks. Without the bit the material isn't known.
		kTriGtaMaterial = 1u << 4,
	};

	inline constexpr std::uint32_t kTriMaterialShift = 8;
	inline constexpr std::uint32_t kTriGtaMaterialShift = 16;  // kTriGtaMaterial

	struct ColTri
	{
		float         v[9];
		std::uint32_t flags;
	};
	static_assert(sizeof(ColTri) == 40);

	struct ColMsgHeader
	{
		std::uint32_t type;
		std::uint32_t payloadBytes;
	};

	// Replaces all Skyrim collision inside the inclusive block box [min, max].
	struct ColRegion
	{
		std::int32_t  minX, minY, minZ;
		std::int32_t  maxX, maxY, maxZ;
		std::uint32_t epoch;
		std::uint32_t count;
	};
	static_assert(sizeof(ColRegion) == 32);

	// One block's worth of Skyrim collision as an 8x8x8 occupancy mask.
	// bits[y] bit (z * 8 + x) is sub-voxel (x, y, z), each 1/8 block, in MC axes.
	struct ColBlock
	{
		std::int32_t  x, y, z;
		std::uint32_t pad;
		std::uint64_t bits[8];
	};
	static_assert(sizeof(ColBlock) == 80);
}
