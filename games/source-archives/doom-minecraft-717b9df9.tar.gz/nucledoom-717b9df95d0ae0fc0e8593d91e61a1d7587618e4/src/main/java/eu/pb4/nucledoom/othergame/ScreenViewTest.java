package eu.pb4.nucledoom.othergame;

import eu.pb4.mapcanvas.api.core.CanvasColor;
import eu.pb4.mapcanvas.api.core.CanvasImage;
import eu.pb4.mapcanvas.api.font.DefaultFonts;
import eu.pb4.mapcanvas.api.utils.CanvasUtils;
import eu.pb4.mapcanvas.impl.image.RawImage;
import eu.pb4.nucledoom.PlayerSaveData;
import eu.pb4.nucledoom.game.*;
import it.unimi.dsi.fastutil.ints.Int2IntArrayMap;
import it.unimi.dsi.fastutil.ints.Int2IntMap;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.player.Input;
import org.jetbrains.annotations.Nullable;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.function.BiConsumer;

public class ScreenViewTest implements DoomGame {
    @Nullable
    private final GameHandler handler;
    private final int[] pressNum = new int[9];
    private final Robot robot;
    private final ScreenInfo screenInfo;
    private final Dimension screenSize;
    private final Rectangle rectangle;
    private volatile boolean close = false;
    private Input input = Input.EMPTY;
    private CanvasImage screen;
    private Int2IntMap keys = new Int2IntArrayMap();

    public ScreenViewTest(@Nullable GameHandler gameHandler,
                          @Nullable PlayerSaveData saveData,
                          DoomConfig config,
                          ResourceManager resourceManager) throws Throwable {
        this.handler = gameHandler;
        this.robot = new Robot();
        this.screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        this.screenInfo = new ScreenInfo(screenSize.width, screenSize.height, ScreenInfo.DEFAULT.background(), ScreenInfo.DEFAULT.overlay(), ScreenInfo.DEFAULT.overlayReset(), 1);
        this.rectangle = new Rectangle(this.screenSize);
    }

    @Override
    public ScreenInfo getScreenInfo() {
        return this.screenInfo;
    }

    @Override
    public boolean onChat(String message) {

        return false;
    }

    @Override
    public void startGameLoop() throws Throwable {
        try {
            while (true) {
                this.drawFrame();
                if (this.close) break;
                Thread.sleep(10);
            }
        } finally {

        }
    }

    @Override
    public void clear() {
        this.close = true;
    }

    public void drawFrame() {
        if (this.close) {
            throw new GameClosed(0);
        }

        if (this.handler == null) {
            return;
        }


        if (this.screen == null) {
            this.screen = new CanvasImage(this.screenInfo.width(), this.screenInfo.height());
        }
        var rgb = this.screen;
        var time = System.currentTimeMillis();
        var image = RawImage.convert(this.robot.createScreenCapture(this.rectangle));


        for (var x = 0; x < this.screenSize.width; x++) {
            for (var y = 0; y < this.screenSize.height; y++) {
                rgb.set(x, y, CanvasUtils.findClosestColor(image.get(x, y)));
            }
        }

        DefaultFonts.VANILLA.drawText(rgb, String.valueOf(System.currentTimeMillis() - time), 8,8, 8, CanvasColor.WHITE_HIGH);
        this.handler.getCanvas().drawFrame(this.screen);
    }

    @Override
    public void updateKeyboard(Input input) {
        if (this.input.right() != input.right()) pressEvent(KeyEvent.VK_D, input.right());
        if (this.input.left() != input.left()) pressEvent(KeyEvent.VK_A, input.left());
        if (this.input.forward() != input.forward()) pressEvent(KeyEvent.VK_W, input.forward());
        if (this.input.backward() != input.backward()) pressEvent(KeyEvent.VK_S, input.backward());
        if (this.input.shift() != input.shift()) pressEvent(KeyEvent.VK_SHIFT, input.shift());
        if (this.input.sprint() != input.sprint()) pressEvent(KeyEvent.CTRL_DOWN_MASK, input.sprint());
        if (this.input.jump() != input.jump()) pressEvent(KeyEvent.VK_SPACE, input.jump());

        this.input = input;
    }

    @Override
    public void updateMouse(float xDelta, float yDelta) {
        double d = 0.6000000238418579 + 0.20000000298023224;
        double e = d * d * d;
        double f = e * 8.0;

        var pos = MouseInfo.getPointerInfo().getLocation();

        var newX = pos.x + (int) (xDelta * 6 / 0.15 / f / 1.5);
        var newY = pos.y + (int) (yDelta * 6 / 0.15 / f / 1.5);
        if (pos.x != newX || pos.y != newY) {
            this.robot.mouseMove(newX, newY);
        }
    }

    @Override
    public void pressMouseLeft(boolean value) {
        if (value) {
            this.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        } else {
            this.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        }
    }

    @Override
    public void pressMouseRight(boolean value) {
        if (value) {
            this.robot.mousePress(InputEvent.BUTTON2_DOWN_MASK);
        } else {
            this.robot.mouseRelease(InputEvent.BUTTON2_DOWN_MASK);
        }
    }

    private void pressEvent(int key, boolean val) {
        if (val) {
            this.robot.keyPress(key);
        } else {
            this.robot.keyRelease(key);
        }
    }

    private void pressTimed(int key) {
        if (this.keys.getOrDefault(key, -1) == -1) {
            this.robot.keyPress(key);
        }
        this.keys.put(key, 2);
    }


    @Override
    public void selectSlot(int selectedSlot) {
        this.pressTimed(selectedSlot);
    }

    @Override
    public void pressE() {
        this.pressTimed(KeyEvent.VK_E);
    }

    @Override
    public void pressQ() {
        this.pressTimed(KeyEvent.VK_Q);
    }

    @Override
    public void pressF() {
        this.pressTimed(KeyEvent.VK_F);
    }

    @Override
    public void tick() {
        var copy = new IntArrayList(this.keys.keySet());
        for (int i = 0; i < copy.size(); i++) {
            var key = copy.getInt(i);
            var val = this.keys.get(key) - 1;
            if (val == 0) {
                this.keys.remove(key);
                this.robot.keyRelease(key);
            } else {
                this.keys.put(key, val);
            }
        }
    }

    @Override
    public void extractAudio(BiConsumer<String, byte[]> consumer) {}

    public void playSound(SoundTarget target, SoundEvent soundVanilla, float pitch, float volume, long seed) {
        if (this.handler != null) {
            this.handler.playSound(target, soundVanilla, pitch, volume, seed);
        }
    }

    public boolean supportsSoundTarget(SoundTarget target) {
        return this.handler != null && this.handler.supportsSoundTargets(target);
    }

    @Override
    public String getControls() {
        return "";
    }
}
